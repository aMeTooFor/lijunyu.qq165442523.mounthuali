package lijunyu.qq165442523.mounthuali.activity;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.widget.Toast;

import com.unnamed.b.atv.model.TreeNode;

import lijunyu.qq165442523.mounthuali.R;
import lijunyu.qq165442523.mounthuali.fragment.CustomViewHolderFragment888;

import static lijunyu.qq165442523.mounthuali.activity.MainActivity.inout;

/**
 * Created by Bogdan Melnychuk on 2/12/15.
 */
public class SingleFragmentActivity extends ActionBarActivity {
    public final static String FRAGMENT_PARAM = "fragment";

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_single_fragment);

        Bundle b = getIntent().getExtras();
        Class<?> fragmentClass = (Class<?>) b.get(FRAGMENT_PARAM);
        if (bundle == null) {
            Fragment f = Fragment.instantiate(this, fragmentClass.getName());
            f.setArguments(b);
            getFragmentManager().beginTransaction().replace(R.id.fragment, f, fragmentClass.getName()).commit();
        }
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //Toast toast=Toast.makeText(this, "onBackPressed", Toast.LENGTH_SHORT);
        //getFragmentManager().popBackStack();
        if (inout.size() > 1) {
            try {
                ((Fragment) inout.get(inout.size() - 1)).getActivity().finish();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
            }
            try {
                inout.remove(inout.size() - 1);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
            }
        }
    }

}

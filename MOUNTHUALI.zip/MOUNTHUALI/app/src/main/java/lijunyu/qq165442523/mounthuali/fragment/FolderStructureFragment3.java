package lijunyu.qq165442523.mounthuali.fragment;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.unnamed.b.atv.model.TreeNode;

import lijunyu.qq165442523.mounthuali.R;
import lijunyu.qq165442523.mounthuali.activity.MainActivity;

import lijunyu.qq165442523.mounthuali.holder.*;


import com.unnamed.b.atv.view.AndroidTreeView;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by Bogdan Melnychuk on 2/12/15.
 */
public class FolderStructureFragment3 extends Fragment {
    private TextView statusBar;
    public AndroidTreeView tView;
    public TreeNode 仲荣=null;
    ArrayList<String> songIDs = new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public static int getdeep(String oneline) {
        for (int i = 1; i < oneline.length(); i++) {
            if ("0123456789".indexOf(oneline.charAt(i)) == -1) {
                return i;
            }
        }
        return -1;

    }
    public  int tree(TreeNode node,String curroot) {

        ArrayList<String> songIDs = MainActivity.readTxt2(curroot+"/子嗣.txt");
        String www = "";
        String vid = "";
        TreeNode cur0=null;
        TreeNode cur=null;
        TreeNode temp0=null;
        TreeNode vParentNode=node;
        //node.getParent().setExpanded(false);
        //tView = new AndroidTreeView(getActivity(), root);
        tView.collapseNode(node.getParent());
        node.deleteChild(node.getChildren().get(0));
        int jj0 = 2;
        int jj = 2;
        for (int i = 0; i < songIDs.size(); i++) {
            if (i ==songIDs.size()-2){
                www="www";
            }
            www = songIDs.get(i).toString();
            // www=www.replaceAll("<","");
            //www=www.replaceAll(">","");

            jj = getdeep(www);
            vid = www.substring(0, jj);
            www = www.substring(jj);

            cur = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_drive_file, www));
            cur.setViewHolder(new SelectableHeaderHolder(MainActivity.mainform));
            cur.ftext2 = vid;
            if (jj==3){
                jj=2;
            }
            if (jj == jj0) {
                vParentNode.addChild(cur);
                //vParentNode.isLeaf();  isLeaf()方法是判断是不是node的叶节点。
                vParentNode.setViewHolder(new IconTreeItemHolder(MainActivity.mainform));
                jj0 = jj;
                cur0 = cur;
            }
            if (jj - jj0 == 2) {
                vParentNode = cur0;
                vParentNode.addChild(cur);
                vParentNode.setViewHolder(new IconTreeItemHolder(MainActivity.mainform));
                jj0 = jj;
                cur0 = cur;
            }
            if (jj < jj0) {
                for (int iFinish = 0; iFinish < Math.floor((jj0 - jj) / 2); iFinish++) {
                    vParentNode = vParentNode.getParent();
                }
                vParentNode.addChild(cur);
                vParentNode.setViewHolder(new IconTreeItemHolder(MainActivity.mainform));
                jj0 = jj;
                cur0 = cur;
            }
            String ppp = curroot+"/图片/" + vid + ".jpg";
            cur.ftext3 = ppp;
            ppp= curroot+"/" + vid ;
            File file = new File(ppp);
            if (file.exists()) {
                temp0 = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_drive_file, "..."));
                temp0.ftext2=ppp;
                cur.addChild(temp0);
                cur.setViewHolder(new IconTreeItemHolder(MainActivity.mainform));
            }

        }
        //node.getParent().setExpanded(true);
        tView.expandNode(node.getParent());
        return 1;

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_default, null, false);

        ViewGroup containerView = (ViewGroup) rootView.findViewById(R.id.container);

        statusBar = (TextView) rootView.findViewById(R.id.status_bar);

        TreeNode root = TreeNode.root();
        TreeNode computerRoot = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_laptop, "黄帝"));

//        TreeNode myDocuments = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, "My Documents"));
//        TreeNode downloads = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, "Downloads"));
//        TreeNode file1 = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_drive_file, "Folder 1"));
//        TreeNode file2 = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_drive_file, "Folder 2"));
//        TreeNode file3 = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_drive_file, "Folder 3"));
//        TreeNode file4 = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_drive_file, "Folder 4"));
//        fillDownloadsFolder(downloads);
//        downloads.addChildren(file1, file2, file3, file4);
//
//        TreeNode myMedia = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_photo_library, "Photos"));
//        TreeNode photo1 = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_photo, "Folder 1"));
//        TreeNode photo2 = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_photo, "Folder 2"));
//        TreeNode photo3 = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_photo, "Folder 3"));


//        myMedia.addChildren(photo1, photo2, photo3);
//
//        myDocuments.addChild(downloads);
//        computerRoot.addChildren(myDocuments, myMedia);
        //computerRoot.


        TreeNode myDocuments = null;
        TreeNode myMedia = null;
        songIDs = MainActivity.readTxt2("/sdcard/原始氏族电子族谱/原始氏族/太祖.txt");
        String www = "";
        for (int i = 0; i < songIDs.size(); i++) {
            www = songIDs.get(i).toString();
            // www=www.replaceAll("<","");
            //www=www.replaceAll(">","");
            myDocuments = (new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_drive_file, www)));
            //  myDocuments = new TreeNode(new ArrowExpandSelectableHeaderHolder.IconTreeItem(R.string.ic_drive_file, www));
            //  myDocuments.setViewHolder(new SelectableItemHolder(MainActivity.mainform));
            if (i < (songIDs.size() - 1)) {
                // myDocuments.setViewHolder(new SelectableHeaderHolder(getActivity()));
                myDocuments.setViewHolder(new SelectableHeaderHolder(MainActivity.mainform));

            }
            myDocuments.setSelectable(false);
            if (myDocuments.isLeaf()) {

            }
            computerRoot.addChild(myDocuments);

        }
        songIDs = MainActivity.readTxt2("/sdcard/原始氏族电子族谱/原始氏族/高祖.txt");
        www = "";
        for (int i = 0; i < songIDs.size(); i++) {
            www = songIDs.get(i).toString();
            // www=www.replaceAll("<","");
            //www=www.replaceAll(">","");

            myMedia = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_laptop, www));
            if (i < (songIDs.size() - 1)) {
                // myDocuments.setViewHolder(new SelectableHeaderHolder(getActivity()));
                myMedia.setViewHolder(new SelectableHeaderHolder(MainActivity.mainform));

            }
            myDocuments.addChild(myMedia);

        }
         仲荣 = myMedia;
        TreeNode temp0 = null;
        TreeNode cur0 = null;
        TreeNode cur = null;
        TreeNode vParentNode = null;
        vParentNode = 仲荣;
        songIDs = MainActivity.readTxt2("/sdcard/原始氏族电子族谱/原始氏族/世祖/子嗣.txt");
        www = "";
        String vid = "";
        int jj0 = 2;
        int jj = 2;
        for (int i = 0; i < songIDs.size(); i++) {
            www = songIDs.get(i).toString();
            // www=www.replaceAll("<","");
            //www=www.replaceAll(">","");

            jj = getdeep(www);
            vid = www.substring(0, jj);
            www = www.substring(jj);

            cur = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_drive_file, www));
            cur.setViewHolder(new SelectableHeaderHolder(MainActivity.mainform));
            cur.ftext2 = vid;
            if (jj == jj0) {
                vParentNode.addChild(cur);
                //vParentNode.isLeaf();  isLeaf()方法是判断是不是node的叶节点。
                vParentNode.setViewHolder(new IconTreeItemHolder(MainActivity.mainform));
                jj0 = jj;
                cur0 = cur;
            }
            if (jj - jj0 == 2) {
                vParentNode = cur0;
                vParentNode.addChild(cur);
                vParentNode.setViewHolder(new IconTreeItemHolder(MainActivity.mainform));
                jj0 = jj;
                cur0 = cur;
            }
            if (jj < jj0) {
                for (int iFinish = 0; iFinish < Math.floor((jj0 - jj) / 2); iFinish++) {
                    vParentNode = vParentNode.getParent();
                }
                vParentNode.addChild(cur);
                vParentNode.setViewHolder(new IconTreeItemHolder(MainActivity.mainform));
                jj0 = jj;
                cur0 = cur;
            }
            String ppp = "/sdcard/原始氏族电子族谱/原始氏族/世祖/图片/" + vid + ".jpg";
            cur.ftext3 = ppp;
            ppp= "/sdcard/原始氏族电子族谱/原始氏族/世祖/" + vid ;
            File file = new File(ppp);
            if (file.exists()) {
                temp0 = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_drive_file, "..."));
                temp0.ftext2=ppp;
                cur.addChild(temp0);
                cur.setViewHolder(new IconTreeItemHolder(MainActivity.mainform));
            }

        }

        // myMedia = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_drive_file, " "));
        //myDocuments.addChild(myMedia);
        // myMedia = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_drive_file, " "));
        //  computerRoot.addChild(myMedia);

        root.addChildren(computerRoot);

        tView = new AndroidTreeView(getActivity(), root);
        tView.setDefaultAnimation(true);
        tView.setDefaultContainerStyle(R.style.TreeNodeStyleCustom);
        //tView.setDefaultContainerStyle(R.style.TreeNodeStyleDivided);
        tView.setDefaultViewHolder(IconTreeItemHolder.class);
        tView.setDefaultNodeClickListener(nodeClickListener);
        tView.setDefaultNodeLongClickListener(nodeLongClickListener);

        containerView.addView(tView.getView());

        if (savedInstanceState != null) {
            String state = savedInstanceState.getString("tState");
            if (!TextUtils.isEmpty(state)) {
                tView.restoreState(state);
            }
        }
        tView.expandLevel(4);
        return rootView;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.expandAll:
               // tView.expandAll();

               tView.expandLevel(4);
                //tView.expandLevel(9);

                tView.expandNode(仲荣);
                tView.toggleNode(仲荣);
//                仲荣.setExpanded(true);
                tView.selectNode(仲荣,true);
                break;

            case R.id.collapseAll:
                tView.collapseAll();
                break;
        }
        return true;
    }

    private int counter = 0;

    private void fillDownloadsFolder(TreeNode node) {
        TreeNode downloads = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, "Downloads" + (counter++)));
        node.addChild(downloads);
        if (counter < 5) {
            fillDownloadsFolder(downloads);
        }
    }

    private TreeNode.TreeNodeClickListener nodeClickListener = new TreeNode.TreeNodeClickListener() {
        @Override
        public void onClick(TreeNode node, Object value) {
            IconTreeItemHolder.IconTreeItem item = (IconTreeItemHolder.IconTreeItem) value;
            statusBar.setText("最近点击的是: " + item.text);
            TreeNode node1=null;
            if (!node.isLeaf()) {
                node1 =node.getChildren().get(0);
                IconTreeItemHolder.IconTreeItem item1 = (IconTreeItemHolder.IconTreeItem) node1.getValue();
                if (item1.text.equals("...")){

                    if (!node.isExpanded()) {
                        //Toast.makeText(getActivity(), node1.ftext2, Toast.LENGTH_SHORT).show();
                        tree(node,node1.ftext2);





                    }
                }
            }
        }
    };

    private TreeNode.TreeNodeLongClickListener nodeLongClickListener = new TreeNode.TreeNodeLongClickListener() {
        @Override
        public boolean onLongClick(TreeNode node, Object value) {
            if (node.getLevel() < 4){
                Toast.makeText(getActivity(), "以下才可弹出菜单信息 ", Toast.LENGTH_SHORT).show();
                return true;
            }
            IconTreeItemHolder.IconTreeItem item = (IconTreeItemHolder.IconTreeItem) value;
            //Toast.makeText(getActivity(), "Long click: " + item.text, Toast.LENGTH_SHORT).show();
            AlertDialog alertDialog1; //信息框
            String 打开相关图片 = "";
            String 第n世 = "";
            String 备注 = "备注:";
            String 认祖归宗 = "认祖归宗：";
            if (node.getLevel() < 3) {
                第n世 = "";
            } else {
                if (node.isLeaf()) {
                    第n世 = "第" + (node.getLevel() - 2) + "世 有子嗣 0 人" + " 兄弟共 " + node.getParent().getChildren().size() + "人";
                } else {
                    第n世 = "第" + (node.getLevel() - 2) + "世 有子嗣 " + node.getChildren().size() + " 人" + " 兄弟共 " + node.getParent().getChildren().size() + "人";
                }
                for (int ijk = 0; ijk < node.getParent().getChildren().size(); ijk++) {
                    if (node.getParent().getChildren().get(ijk).equals(node)) {
                        第n世 = 第n世 + " 在兄弟中排行第 " + (ijk + 1);
                    }
                }
            }
            第n世 = 第n世 + " 说明：子嗣数是动态统计，如果显示0，也可能是没有录入数据之因，特此说明。 ";
            /////////////////////////////////////
            ArrayList<String> 子嗣 = null;
            ArrayList<String> 附加 = null;
            子嗣 = MainActivity.readTxt2("/sdcard/原始氏族电子族谱/原始氏族/世祖/子嗣.txt");
            String www = "";
            String vid = "";
            String vvid = "";
            int jj0 = 2;
            int jj = 2;
            for (int i = 0; i < 子嗣.size(); i++) {
                www = 子嗣.get(i).toString();
                // www=www.replaceAll("<","");
                //www=www.replaceAll(">","");

                jj = getdeep(www);
                vid = www.substring(0, jj);
                www = www.substring(jj);
                if (item.text.equals(www)) {
                    break;
                }
            }

            vid = node.ftext2;
            附加 = MainActivity.readTxt2("/sdcard/原始氏族电子族谱/原始氏族/世祖/附加.txt");
            www = "";
            vvid = "";
            jj0 = 2;
            jj = 2;
            for (int i = 0; i < 附加.size(); i++) {
                www = 附加.get(i).toString();
                // www=www.replaceAll("<","");
                //www=www.replaceAll(">","");

                jj = getdeep(www);
                vvid = www.substring(0, jj);
                www = www.substring(jj);
                if (vid.equals(vvid)) {
                    备注 = "备注:" + www;
                    break;
                }
            }
            //vvid = node.ftext2;
            /////////////////////////////////////////
            认祖归宗 = "认祖归宗：";
            TreeNode curnode = node;
            IconTreeItemHolder.IconTreeItem curitem = (IconTreeItemHolder.IconTreeItem) curnode.getValue();
            while (!curitem.text.equals("黄帝")) {
                if (curitem.text.indexOf("<") > 0) {
                    认祖归宗 = 认祖归宗 + curitem.text.substring(0, curitem.text.indexOf("<")) + "->";
                } else {
                    认祖归宗 = 认祖归宗 + curitem.text + "->";
                }
                curnode = curnode.getParent();
                curitem = (IconTreeItemHolder.IconTreeItem) curnode.getValue();
            }
            认祖归宗 = 认祖归宗 + "黄帝";
            认祖归宗 = 认祖归宗.replace("仲荣->晟->黄帝", "仲荣->...->晟->...->黄帝");

            final String ppp = node.ftext3;
            File dir = new File(ppp);
            if (!dir.exists()) {
                打开相关图片 = "找不到相关图片";
            } else {
                打开相关图片 = "打开相关图片";
            }
            final String[] items = {打开相关图片, 第n世, 备注, 认祖归宗};
            AlertDialog.Builder alertBuilder = new AlertDialog.Builder(getActivity());
            alertBuilder.setTitle("【" + item.text + "】");
            alertBuilder.setItems(items, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (items[i].equals("打开相关图片")) {
                        //Toast.makeText(getActivity(), "【打开相关图片】功能还在开发中...", Toast.LENGTH_SHORT).show();

                        File file = new File(ppp);
                        if (!file.exists()) {
                            return;
                        }
                        try {

//                            Intent intents = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
////                            intents.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(file));
////                            startActivity(intents);
                            //File file = new File(filepath);
                            ImageView imageView = new ImageView(getActivity());//创建一个imageView对象
                            if (file.exists()) {
                                Bitmap bm = BitmapFactory.decodeFile(ppp);
                                // 将图片显示到ImageView中
                                imageView.setImageBitmap(bm);
                                //linearLayout1.addView(imageView);
                                AlertDialog alertDialog = new AlertDialog
                                        .Builder(getActivity())
                                        .setView(imageView)
                                        .create();

                                alertDialog.show();



                            }









                        } catch (Exception e) {
                            Toast.makeText(getActivity(), "已找到图片，但无法显示", Toast.LENGTH_SHORT).show();

                        }
                    }

                }
            });
            alertBuilder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {
                    // TODO Auto-generated method stub
                    dialog.dismiss();
                }
            });


            alertDialog1 = alertBuilder.create();
            alertDialog1.show();
            return true;
        }
    };

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("tState", tView.getSaveState());
    }
}

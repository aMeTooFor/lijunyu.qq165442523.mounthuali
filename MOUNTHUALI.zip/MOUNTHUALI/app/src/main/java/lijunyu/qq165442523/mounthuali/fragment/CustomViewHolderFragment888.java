package lijunyu.qq165442523.mounthuali.fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.unnamed.b.atv.model.TreeNode;
import com.unnamed.b.atv.view.AndroidTreeView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;

import lijunyu.qq165442523.mounthuali.R;
import lijunyu.qq165442523.mounthuali.activity.MainActivity;
import lijunyu.qq165442523.mounthuali.activity.SingleFragmentActivity;
import lijunyu.qq165442523.mounthuali.holder.HeaderHolder;
import lijunyu.qq165442523.mounthuali.holder.IconTreeItemHolder;
import lijunyu.qq165442523.mounthuali.holder.SelectableHeaderHolder;
import lijunyu.qq165442523.mounthuali.holder.SelectableItemHolder;

import static lijunyu.qq165442523.mounthuali.activity.MainActivity.*;


public class CustomViewHolderFragment888 extends Fragment {

    private AndroidTreeView tView;
    public TreeNode 晟 = null;
    public TreeNode 仲荣 = null;
    public TreeNode 景明 = null;
    public TreeNode 黄帝 = null;
    ArrayList<String> songIDs = new ArrayList<>();
    public String path0 = null;
    public int level0 = 0;
    public TextView sb = null;
    public TreeNode curroot = null;
    public TreeNode curroot000 = null;
    public String tmpPicturePath = null;
    public Activity mainformthis;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

        //Intent intent = getIntent("");
        //path0 = (String)intent.getStringExtra("path0");
        //level0 = Integer.parseInt((String)intent.getStringExtra("level0"));
        mainformthis = this.getActivity();
        path0 = MainActivity.path0;
        level0 = MainActivity.level0;
        curroot = MainActivity.curroot;
        curroot000 = MainActivity.curroot000;
        if (MainActivity.curroot == null) {
            level0 = 0;
            path0 = "";
            curroot = null;
        }
        if (MainActivity.firstform == null) {
            MainActivity.firstform = CustomViewHolderFragment888.this;
        }
        String www = "";
        if (curroot != null) {
            if (curroot.isLeaf()) {
                www = curroot.getValue().toString();
            } else {
                IconTreeItemHolder.IconTreeItem curitem = (IconTreeItemHolder.IconTreeItem) curroot.getValue();
                www = curitem.text;
            }
        }

        MainActivity.addFragment(this, www);

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
        //回退到一世界面    回退十步


    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        //回退到一世界面    回退十步
        ((MenuItem) menu.findItem(R.id.expandAll)).setTitle("倒退回到一世");
        ((MenuItem) menu.findItem(R.id.collapseAll)).setTitle("倒退十世");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.expandAll:

                gohome(0);
                break;

            case R.id.collapseAll:

                gohome(10);
                break;
        }
        return true;
    }

    public static String getpathstr(TreeNode node) {
        String www = "";
        TreeNode curnode = node;
        //TreeNode curnode = node;
        IconTreeItemHolder.IconTreeItem curitem = (IconTreeItemHolder.IconTreeItem) curnode.getValue();
        //while (!curitem.text.equals("黄帝")) {
        while (!node.getRoot().equals(curnode)) {
            if (curitem.text.indexOf("<") > 0) {
                www = www + curitem.text.substring(0, curitem.text.indexOf("<")) + "->";
            } else {
                www = www + curitem.text + "->";
            }
            curnode = curnode.getParent();
            curitem = (IconTreeItemHolder.IconTreeItem) curnode.getValue();
        }
        www = www.replace("仲荣->晟->黄帝", "仲荣...晟...黄帝");

        www = www.replace("->null", "");

        return www;


    }

    public static String getrootnodepathstr(TreeNode node) {
        String www = "";
        String nodetext = "";
        TreeNode curnode = null;//node;
        //TreeNode curnode = node;

        for (int i = inout.size() - 1; i > 0; i--) {
            curnode = ((CustomViewHolderFragment888) inout.get(i)).curroot;
            if (curnode == null) {
                break;
            }
            IconTreeItemHolder.IconTreeItem curitem = (IconTreeItemHolder.IconTreeItem) curnode.getValue();
            nodetext = curitem.text;
            if (nodetext.indexOf("<") > 0) {
                nodetext = nodetext.substring(0, nodetext.indexOf("<")) + "->";
            } else {
                nodetext = nodetext + "->";
            }
            www = www + nodetext;
        }
        return www;
    }

    public static int getdeep(String oneline) {
        int ii = -1;
        for (int i = 1; i < oneline.length() + 1; i++) {
            ii = i;
            if (ii == oneline.length()) {
                return i;
            } else {
                if ("0123456789".indexOf(oneline.charAt(i)) == -1) {
                    return i;
                }
            }
        }
        if (ii == oneline.length()) {
            return ii;
        }
        return -1;

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_default, null, false);
        final ViewGroup containerView = (ViewGroup) rootView.findViewById(R.id.container);
        rootView.findViewById(R.id.status_bar).setVisibility(View.VISIBLE);
        sb = rootView.findViewById(R.id.status_bar);
        if (level0 == 0) {
            sb.setText("");
        } else {
            //sb.setText(getpathstr(curroot) + "\n" + getrootnodepathstr(curroot));
            sb.setText(getpathstr(curroot));
        }
        //以下为测试时对比用
        sb.setText(sb.getText() + "\n" + "");
        final TreeNode root = TreeNode.root();
        String www = "";
        TreeNode myProfile = null;
        //回退之时，不是null，但不触发onCreateView，所以在onCreateView中用null可行，在不是onCreateView中不可用null作IF
        if (MainActivity.curroot == null) {
            myProfile = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, "太祖"));
            // TreeNode myProfile = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_people, "黄帝")).setViewHolder(new HeaderHolder(getActivity()));
            myProfile.setViewHolder(new HeaderHolder(getActivity()));
            黄帝 = myProfile;
            addProfileData(myProfile);

        } else {
            //myProfile = MainActivity.curroot;

            if (curroot.isLeaf()) {
                www = curroot.getValue().toString();
                myProfile = new TreeNode(www).setViewHolder(new SelectableItemHolder(getActivity()));
            } else {

                IconTreeItemHolder.IconTreeItem curitem = (IconTreeItemHolder.IconTreeItem) curroot.getValue();
                www = curitem.text;
                myProfile = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, www));
                myProfile.setViewHolder(new HeaderHolder(getActivity()));
            }
            myProfile.ftext2 = curroot.ftext2;
            myProfile.ftext3 = curroot.ftext3;
            //copyChildTree(MainActivity.curroot, myProfile);
            //myProfile.getParent().deleteChild(myProfile);
            copyChildren(curroot, myProfile);
        }
        if (MainActivity.curroot == null) {
            root.addChild(myProfile);
        } else {
            root.addChildren(myProfile.getChildren());
        }


        tView = new AndroidTreeView(getActivity(), root);
        tView.setDefaultAnimation(true);
        //tView.setDefaultContainerStyle(R.style.TreeNodeStyleDivided, true);
        tView.setDefaultContainerStyle(R.style.TreeNodeStyleCustom, true);
        //tView.setDefaultContainerStyle(R.style.TreeNodeStyleDivided);
        tView.setDefaultNodeClickListener(nodeClickListener);
        tView.setDefaultNodeLongClickListener(nodeLongClickListener);
        //containerView.removeAllViews();
        //tView.
        containerView.addView(tView.getView());
        if (MainActivity.curroot == null) {
            tView.expandLevel(3);
        }
        //MainActivity.addFragment(this, www);
        //Caused by: java.lang.IllegalStateException: Can not perform this action after onSaveInstanceState
        if (savedInstanceState != null) {
            String state = savedInstanceState.getString("tState");
            if (!TextUtils.isEmpty(state)) {
                tView.restoreState(state);
            }
        }


        return rootView;
    }


    private void copyChildren(TreeNode fromroot, TreeNode toroot) {
        String www = "";
        if (fromroot.isLeaf()) {

        } else {
            for (int i = 0; i < fromroot.getChildren().size(); i++) {
                TreeNode cur = fromroot.getChildren().get(i);
                if (cur.isLeaf()) {
                    www = cur.getValue().toString();
                    TreeNode myProfile = new TreeNode(www).setViewHolder(new SelectableItemHolder(getActivity()));
                    myProfile.ftext2 = cur.ftext2;
                    myProfile.ftext3 = cur.ftext3;
                    toroot.addChild(myProfile);
                    //copyChildTree(cur, myProfile);
                } else {

                    IconTreeItemHolder.IconTreeItem curitem = (IconTreeItemHolder.IconTreeItem) cur.getValue();
                    www = curitem.text;
                    TreeNode myProfile = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, www));
                    myProfile.setViewHolder(new HeaderHolder(getActivity()));
                    myProfile.ftext2 = cur.ftext2;
                    myProfile.ftext3 = cur.ftext3;
                    toroot.addChild(myProfile);
                    //copyChildTree(cur, myProfile);
                }
            }

        }


    }

    private void copyChildTree(TreeNode fromroot, TreeNode toroot) {
        String www = "";
        if (fromroot.isLeaf()) {

        } else {
            for (int i = 0; i < fromroot.getChildren().size(); i++) {
                TreeNode cur = fromroot.getChildren().get(i);
                if (cur.isLeaf()) {
                    www = cur.getValue().toString();
                    TreeNode myProfile = new TreeNode(www).setViewHolder(new SelectableItemHolder(getActivity()));
                    myProfile.ftext2 = cur.ftext2;
                    myProfile.ftext3 = cur.ftext3;
                    toroot.addChild(myProfile);
                    copyChildTree(cur, myProfile);
                } else {

                    IconTreeItemHolder.IconTreeItem curitem = (IconTreeItemHolder.IconTreeItem) cur.getValue();
                    www = curitem.text;
                    TreeNode myProfile = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, www));
                    myProfile.setViewHolder(new HeaderHolder(getActivity()));
                    myProfile.ftext2 = cur.ftext2;
                    myProfile.ftext3 = cur.ftext3;
                    toroot.addChild(myProfile);
                    copyChildTree(cur, myProfile);
                }
            }

        }


    }

    private void addProfileData(TreeNode profile) {
        TreeNode myDocuments = null;
        TreeNode myMedia = null;

        songIDs = MainActivity.readTxt2("/sdcard/原始氏族电子族谱/原始氏族/太祖.txt");
        String www = "";
        for (int i = 0; i < songIDs.size(); i++) {
            www = songIDs.get(i).toString();

            myDocuments = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_people, www)).setViewHolder(new HeaderHolder(getActivity()));
            profile.addChild(myDocuments);
        }
        songIDs = MainActivity.readTxt2("/sdcard/原始氏族电子族谱/原始氏族/高祖.txt");
        www = "";
        晟 = myDocuments;
        for (int i = 0; i < songIDs.size(); i++) {
            www = songIDs.get(i).toString();

            myMedia = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_people, www)).setViewHolder(new HeaderHolder(getActivity()));
            myDocuments.addChild(myMedia);

        }
        仲荣 = myMedia;
        TreeNode temp0 = null;
        TreeNode cur0 = null;
        TreeNode cur = null;
        TreeNode vParentNode = null;
        vParentNode = 仲荣;
        songIDs = MainActivity.readTxt2("/sdcard/原始氏族电子族谱/原始氏族/世祖/子嗣.txt");
        www = "";
        String vid = "";
        int jj0 = 2;
        int jj = 2;
        for (int i = 0; i < songIDs.size(); i++) {
            www = songIDs.get(i).toString();
            // www=www.replaceAll("<","");
            //www=www.replaceAll(">","");
            jj = getdeep(www);
            vid = www.substring(0, jj);
            www = www.substring(jj);
            if (jj == 3) {
                jj = 2;
            }

            boolean ishavechild = false;
            if ((new File("/sdcard/原始氏族电子族谱/原始氏族/世祖/" + vid)).exists()) {
                ishavechild = true;
            }
            if (i >= (songIDs.size() - 1)) {
                ishavechild = false;
            } else {
                if (getdeep(songIDs.get(i + 1).toString()) == (jj + 2)) {
                    ishavechild = true;
                }
            }
            if (ishavechild) {//////ic_people  ic_person
                cur = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, www)).setViewHolder(new SelectableHeaderHolder(getActivity()));

            } else {
                //cur = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_person, www)).setViewHolder(new SelectableItemHolder(getActivity()));
                cur = new TreeNode(www).setViewHolder(new SelectableItemHolder(getActivity()));
            }
            cur.ftext2 = vid;

            if (jj == jj0) {
                vParentNode.addChild(cur);

                jj0 = jj;
                cur0 = cur;
            }
            if (jj - jj0 == 2) {
                vParentNode = cur0;
                vParentNode.addChild(cur);

                jj0 = jj;
                cur0 = cur;
            }
            if (jj < jj0) {
                for (int iFinish = 0; iFinish < Math.floor((jj0 - jj) / 2); iFinish++) {
                    vParentNode = vParentNode.getParent();
                }
                vParentNode.addChild(cur);

                jj0 = jj;
                cur0 = cur;
            }
            if (www.equals("二世祖")) {
                景明 = cur;
            }
            String ppp = "/sdcard/原始氏族电子族谱/原始氏族/世祖/图片/" + vid + ".jpg";
            cur.ftext3 = ppp;
            ppp = "/sdcard/原始氏族电子族谱/原始氏族/世祖/" + vid;


        }
    }

    private TreeNode.TreeNodeClickListener nodeClickListener = new TreeNode.TreeNodeClickListener() {
        @Override
        public void onClick(TreeNode node, Object value) {

            if (level0 == 0) {
                // if (MainActivity.curroot == null) {
                if (node.getLevel() < 4) {
                    return;
                }
            }
            TreeNode node000 = null;
            if (level0 == 0) {
                node000 = node;
            } else {
                node000 = curroot.getChildren().get(node.getParent().getChildren().indexOf(node));
            }
            if (node000.isLeaf()) {
                return;
            }
            TreeNode node1 = null;
            final TreeNode node111 = node000;

            node1 = node111;

            String nodetext = "";
            if (node111.isLeaf()) {
                nodetext = value.toString();
            } else {
                IconTreeItemHolder.IconTreeItem item = (IconTreeItemHolder.IconTreeItem) node111.getValue();
                nodetext = item.text;
            }
            String 认祖归宗0 = "";
            if (nodetext.indexOf("<") > 0) {
                认祖归宗0 = 认祖归宗0 + nodetext.substring(0, nodetext.indexOf("<")) + "->";
            } else {
                认祖归宗0 = 认祖归宗0 + nodetext + "->";
            }
            //认祖归宗0 = 认祖归宗0 + nodetext + "->";
            TreeNode curnode = node111.getParent();
            //TreeNode curnode = node;
            IconTreeItemHolder.IconTreeItem curitem = (IconTreeItemHolder.IconTreeItem) curnode.getValue();
            //while (!curitem.text.equals("黄帝")) {
            while (!curnode.getRoot().equals(curnode)) {
                if (curitem.text.indexOf("<") > 0) {
                    认祖归宗0 = 认祖归宗0 + curitem.text.substring(0, curitem.text.indexOf("<")) + "->";
                } else {
                    认祖归宗0 = 认祖归宗0 + curitem.text + "->";
                }
                curnode = curnode.getParent();
                curitem = (IconTreeItemHolder.IconTreeItem) curnode.getValue();
            }

            if (level0 == 0) {
                认祖归宗0 = 认祖归宗0.replace("->null", "");
            }
            认祖归宗0 = 认祖归宗0.replace("仲荣->晟->黄帝", "仲荣...晟...黄帝");

            MainActivity.path0 = 认祖归宗0;
            if (level0 == 0) {
                MainActivity.level0 = node111.getLevel() + level0 - 2;
            } else {
                MainActivity.level0 = node111.getLevel() + level0;
            }
            node111.setExpanded(false);
            tView.collapseNode(node111);

            MainActivity.curroot = node111;
            if (curroot == null) {
                MainActivity.curroot000 = 黄帝;
            } else {
                MainActivity.curroot000 = curroot;
            }
            Intent iii = new Intent(getActivity(), SingleFragmentActivity.class);
            iii.putExtra(SingleFragmentActivity.FRAGMENT_PARAM, CustomViewHolderFragment888.class);
            getActivity().startActivity(iii);

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    node111.setExpanded(false);
                    tView.collapseNode(node111);
                }
            }, 500);
        }
    };

    private TreeNode.TreeNodeLongClickListener nodeLongClickListener = new TreeNode.TreeNodeLongClickListener() {
        @Override
        public boolean onLongClick(TreeNode node, Object value) {
            if (level0 == 0) {
                if (node.getLevel() < 4) {
                    Toast.makeText(getActivity(), "第四世以下才可弹出菜单信息 ", Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
            TreeNode node000 = null;
            if (level0 == 0) {
                node000 = node;
            } else {
                node000 = curroot.getChildren().get(node.getParent().getChildren().indexOf(node));
            }
            node = node000;
            String nodetext = "";
            if (node.isLeaf()) {
                nodetext = value.toString();
            } else {
                IconTreeItemHolder.IconTreeItem item = (IconTreeItemHolder.IconTreeItem) value;
                nodetext = item.text;
            }
            //Toast.makeText(getActivity(), "Long click: " + item.text, Toast.LENGTH_SHORT).show();
            AlertDialog alertDialog1; //信息框
            String 打开相关图片 = "";
            String 第n世 = "";
            String 备注 = "备注:";
            String 认祖归宗 = "认祖归宗：";

            if (level0 == 0) {
                if (node000.isLeaf()) {
                    第n世 = "第" + (node.getLevel() + level0 - 2) + "世 有子嗣 0 人" + " 兄弟共 " + node.getParent().getChildren().size() + "人";
                } else {
                    第n世 = "第" + (node.getLevel() + level0 - 2) + "世 有子嗣 " + node.getChildren().size() + " 人" + " 兄弟共 " + node.getParent().getChildren().size() + "人";
                }
            } else {
                if (node000.isLeaf()) {
                    第n世 = "第" + (node.getLevel() - 2) + "世 有子嗣 0 人" + " 兄弟共 " + node.getParent().getChildren().size() + "人";
                } else {
                    第n世 = "第" + (node.getLevel() - 2) + "世 有子嗣 " + node.getChildren().size() + " 人" + " 兄弟共 " + node.getParent().getChildren().size() + "人";
                }
            }
            for (int ijk = 0; ijk < node.getParent().getChildren().size(); ijk++) {
                if (node.getParent().getChildren().get(ijk).equals(node)) {
                    第n世 = 第n世 + " 在兄弟中排行第 " + (ijk + 1);
                }
            }

            第n世 = "③" + 第n世 + " 说明：子嗣数是动态统计，如果显示0，也可能是没有录入数据之因，特此说明。 ";
            /////////////////////////////////////
            ArrayList<String> 子嗣 = null;
            ArrayList<String> 附加 = null;
            String vpath = node.ftext3;
            vpath = vpath.replace("/图片/", "/");
            vpath = vpath.substring(0, vpath.lastIndexOf("/"));
            // vpath=vpath+"/子嗣.txt";
            子嗣 = MainActivity.readTxt2(vpath + "/子嗣.txt");
            String www = "";
            String vid = "";
            String vvid = "";
            int jj0 = 2;
            int jj = 2;
            for (int i = 0; i < 子嗣.size(); i++) {
                www = 子嗣.get(i).toString();
                // www=www.replaceAll("<","");
                //www=www.replaceAll(">","");

                jj = getdeep(www);
                vid = www.substring(0, jj);
                www = www.substring(jj);
                if (nodetext.equals(www)) {
                    break;
                }
            }

            vid = node.ftext2;
            附加 = MainActivity.readTxt2(vpath + "/附加.txt");
            www = "";
            vvid = "";
            jj0 = 2;
            jj = 2;
            for (int i = 0; i < 附加.size(); i++) {
                www = 附加.get(i).toString();
                // www=www.replaceAll("<","");
                //www=www.replaceAll(">","");

                jj = getdeep(www);
                vvid = www.substring(0, jj);
                www = www.substring(jj);
                if (vid.equals(vvid)) {
                    备注 = "④备注:" + www;
                    break;
                }
            }
            //vvid = node.ftext2;
            /////////////////////////////////////////
            认祖归宗 = "⑤认祖归宗：";
            String 认祖归宗0 = "";
            if (nodetext.indexOf("<") > 0) {
                认祖归宗 = 认祖归宗 + nodetext.substring(0, nodetext.indexOf("<")) + "->";
            } else {
                认祖归宗 = 认祖归宗 + nodetext + "->";
            }
            //认祖归宗 = 认祖归宗 + nodetext + "->";
            //认祖归宗0 = 认祖归宗0 + nodetext + "->";
            TreeNode curnode = node.getParent();
            //TreeNode curnode = node;
            IconTreeItemHolder.IconTreeItem curitem = (IconTreeItemHolder.IconTreeItem) curnode.getValue();
            //while (!curitem.text.equals("黄帝")) {
            while (!node.getRoot().equals(curnode)) {
                if (curitem.text.indexOf("<") > 0) {
                    认祖归宗 = 认祖归宗 + curitem.text.substring(0, curitem.text.indexOf("<")) + "->";
                    认祖归宗0 = 认祖归宗0 + curitem.text.substring(0, curitem.text.indexOf("<")) + "->";
                } else {
                    认祖归宗 = 认祖归宗 + curitem.text + "->";
                    认祖归宗0 = 认祖归宗0 + curitem.text + "->";
                }
                curnode = curnode.getParent();
                curitem = (IconTreeItemHolder.IconTreeItem) curnode.getValue();
            }

            认祖归宗 = 认祖归宗.replace("仲荣->晟->黄帝", "仲荣...晟...黄帝");
            认祖归宗0 = 认祖归宗0.replace("仲荣->晟->黄帝", "仲荣...晟...黄帝");
            if (level0 == 0) {
                认祖归宗 = 认祖归宗.replace("->null", "");
                认祖归宗0 = 认祖归宗0.replace("->null", "");
            }
            final String ppp = node.ftext3;
            File dir = new File(ppp);
            if (!dir.exists()) {
                打开相关图片 = "② 找不到相关图片";
            } else {
                打开相关图片 = "② 打开相关图片";
            }

            final TreeNode currootnode = node;
            String 头胎 = "添加第一个子嗣";
            if (!currootnode.isLeaf()) {
                头胎 = "无需" + 头胎;
            }

            final String[] items = {打开相关图片, 第n世, 备注, 认祖归宗, "编辑名字", 头胎, "添加兄长", "添加弟弟", "编辑备注", "删除子树", "插入/修改图片"};
            AlertDialog.Builder alertBuilder = new AlertDialog.Builder(getActivity());
            alertBuilder.setTitle("【" + nodetext + "】");


            final String 认祖归宗00 = 认祖归宗0.replace("⑤认祖归宗：", "");

            final String finalNodetext = nodetext;
            final String final原来备注 = 备注.replace("④备注:", "");
            final ArrayList<String> final子嗣 = 子嗣;
            final ArrayList<String> final附加 = 附加;
            final String finalVpath = vpath;
            final String finalvid = vid;
            alertBuilder.setItems(items, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (items[i].equals("② 打开相关图片")) {

                        File file = new File(ppp);
                        if (!file.exists()) {
                            return;
                        }
                        try {

                            ImageView imageView = new ImageView(getActivity());//创建一个imageView对象
                            if (file.exists()) {
                                Bitmap bm = BitmapFactory.decodeFile(ppp);

                                imageView.setImageBitmap(bm);

                                AlertDialog alertDialog = new AlertDialog
                                        .Builder(getActivity())
                                        .setView(imageView)
                                        .create();

                                alertDialog.show();


                            }


                        } catch (Exception e) {
                            Toast.makeText(getActivity(), "已找到图片，但无法显示", Toast.LENGTH_SHORT).show();

                        }
                    }
                    if (items[i].equals("①作为根节点打开")) {

                        MainActivity.curroot = currootnode;
                        MainActivity.curroot000 = curroot;
                        Intent iii = new Intent(getActivity(), SingleFragmentActivity.class);
                        iii.putExtra(SingleFragmentActivity.FRAGMENT_PARAM, CustomViewHolderFragment888.class);
                        iii.putExtra("path0", 认祖归宗00);
                        iii.putExtra("level0", curroot.getLevel() + level0 - 1);
                        MainActivity.path0 = 认祖归宗00;
                        MainActivity.level0 = curroot.getLevel() + level0 - 1;

                        getActivity().startActivity(iii);

                    }
                    if (items[i].equals("编辑名字")) {//"编辑名字","添加子嗣","插入兄长","编辑备注","删除子树"
                        final EditText etView = new EditText(getActivity());//创建一个imageView对象
                        etView.setText(finalNodetext);
                        AlertDialog alertDialog = new AlertDialog
                                .Builder(getActivity())
                                .setView(etView)
                                .setTitle("编辑名字")
                                .setMessage(finalNodetext)
                                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        String www = null;
                                        int jj = 0;
                                        String vid = null;
                                        //ArrayList<String> 子嗣save = final子嗣;
                                        ArrayList<String> 子嗣save = new ArrayList();
                                        for (int i = 0; i < final子嗣.size(); i++) {
                                            www = final子嗣.get(i).toString();
                                            // www=www.replaceAll("<","");
                                            //www=www.replaceAll(">","");
                                            jj = getdeep(www);
                                            vid = www.substring(0, jj);
                                            www = www.substring(jj);
                                            //if (finalNodetext.equals(www)) {
                                            if (finalvid.equals(vid)) {
                                                子嗣save.add(final子嗣.get(i).toString().replace(finalNodetext, etView.getText().toString()));
                                            } else {
                                                子嗣save.add(final子嗣.get(i).toString());
                                            }
                                        }
                                        try {
                                            save(子嗣save, finalVpath + "/子嗣.txt");
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        } finally {
                                        }

                                        TreeNode myProfile222 = currootnode.getParent();

                                        TreeNode myProfile = null;
                                        if (currootnode.isLeaf()) {
                                            myProfile = new TreeNode(etView.getText().toString()).setViewHolder(new SelectableItemHolder(getActivity()));
                                            myProfile.ftext2 = currootnode.ftext2;
                                            myProfile.ftext3 = currootnode.ftext3;

                                        } else {
                                            IconTreeItemHolder.IconTreeItem curitem = (IconTreeItemHolder.IconTreeItem) currootnode.getValue();
                                            myProfile = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, etView.getText().toString()));
                                            myProfile.setViewHolder(new HeaderHolder(getActivity()));
                                            myProfile.ftext2 = currootnode.ftext2;
                                            myProfile.ftext3 = currootnode.ftext3;
                                            myProfile.addChildren(currootnode.getChildren());

                                        }
                                        ArrayList<TreeNode> 子嗣 = new ArrayList<>();
                                        int tmpcc = myProfile222.getChildren().size();
                                        for (int ii = 0; ii < tmpcc; ii++) {
                                            TreeNode cur = myProfile222.getChildren().get(ii);
                                            if (cur.equals(currootnode)) {
                                                子嗣.add(myProfile);

                                            } else {
                                                子嗣.add(cur);

                                            }
                                        }
                                        do {
                                            myProfile222.deleteChild(myProfile222.getChildren().get(0));
                                        } while (myProfile222.getChildren().size() > 0);
                                        for (int ii = 0; ii < 子嗣.size(); ii++) {
                                            TreeNode cur = 子嗣.get(ii);
                                            myProfile222.addChild(cur);
                                        }

                                        getActivity().finish();
                                        MainActivity.inout.remove(MainActivity.inout.size() - 1);
                                        MainActivity.curroot = myProfile222;
                                        MainActivity.curroot000 = curroot;
                                        Intent iii = new Intent(getActivity(), SingleFragmentActivity.class);
                                        iii.putExtra(SingleFragmentActivity.FRAGMENT_PARAM, CustomViewHolderFragment888.class);
                                        ((Fragment) MainActivity.inout.get(MainActivity.inout.size() - 1)).getActivity().startActivity(iii);

                                    }
                                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        // TODO Auto-generated method stub
                                    }
                                })
                                .create();
                        alertDialog.show();
                    }
                    if (items[i].
                            equals("添加第一个子嗣")) {//"编辑名字","添加子嗣","插入兄长","编辑备注","删除子树"
                        final EditText etView = new EditText(getActivity());//创建一个imageView对象
                        etView.setText("添加第一个子嗣" + finalNodetext);
                        AlertDialog alertDialog = new AlertDialog
                                .Builder(getActivity())
                                .setView(etView)
                                .setTitle("添加第一个子嗣")
                                .setMessage("添加第一个子嗣" + finalNodetext)
                                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        String www = null;
                                        String www2 = null;
                                        int jj = 0;
                                        String vid = null;
                                        int final子嗣size = final子嗣.size();

                                        //ArrayList<String> 子嗣save = final子嗣;
                                        ArrayList<String> 子嗣save = new ArrayList();
                                        ArrayList<String> 附加save = new ArrayList();
                                        for (int i = 0; i < final子嗣.size(); i++) {
                                            www = final子嗣.get(i).toString();
                                            // www=www.replaceAll("<","");
                                            //www=www.replaceAll(">","");
                                            jj = getdeep(www);
                                            vid = www.substring(0, jj);
                                            www = www.substring(jj);
                                            if (vid.indexOf(finalvid) == 0) {
                                                //if (finalvid.equals(vid)) {
                                                子嗣save.add(final子嗣.get(i).toString());
                                                附加save.add(final附加.get(i).toString());
                                                if (currootnode.isLeaf()) {
                                                    子嗣save.add(finalvid + "01" + etView.getText().toString());
                                                    //子嗣save.add(final子嗣.get(i).toString().replace(finalNodetext, etView.getText().toString()));
                                                    附加save.add(finalvid + "01");
                                                } else {
                                                    www2 = final子嗣.get(i + 1).toString();
                                                    www2 = www2.substring(0, getdeep(www2));
                                                    if (www2.indexOf(finalvid) == 0) {

                                                    } else {
                                                        子嗣save.add(finalvid + pu0(currootnode.getChildren().size() + 1) + etView.getText().toString());
                                                        //子嗣save.add(final子嗣.get(i).toString().replace(finalNodetext, etView.getText().toString()));
                                                        附加save.add(finalvid + pu0(currootnode.getChildren().size() + 1));
                                                    }
                                                }
                                            } else {
                                                子嗣save.add(final子嗣.get(i).toString());
                                                附加save.add(final附加.get(i).toString());
                                            }
                                        }
                                        try {
                                            save(子嗣save, finalVpath + "/子嗣.txt");
                                            save(附加save, finalVpath + "/附加.txt");
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        } finally {
                                        }

                                        TreeNode myProfile = null;
                                        TreeNode myProfile222 = null;

                                        myProfile = new TreeNode(etView.getText().toString()).setViewHolder(new SelectableItemHolder(getActivity()));
                                        myProfile.ftext2 = finalvid + pu0(currootnode.getChildren().size() + 1);

                                        myProfile.ftext3 = finalVpath + "/图片/" + myProfile.ftext2 + ".jpg";
                                        ;
                                        if (currootnode.isLeaf()) {

                                            myProfile222 = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, finalNodetext));
                                            myProfile222.setViewHolder(new SelectableHeaderHolder(getActivity()));
                                            myProfile222.ftext2 = currootnode.ftext2;
                                            myProfile222.ftext3 = currootnode.ftext3;
                                            myProfile222.addChild(myProfile);

                                            TreeNode myProfile2223 = currootnode.getParent();

                                            ArrayList<TreeNode> 子嗣 = new ArrayList<>();
                                            int tmpcc = myProfile2223.getChildren().size();
                                            for (int ii = 0; ii < tmpcc; ii++) {
                                                TreeNode cur = myProfile2223.getChildren().get(ii);
                                                if (cur.equals(currootnode)) {
                                                    子嗣.add(myProfile222);

                                                } else {
                                                    子嗣.add(cur);
                                                }
                                            }
                                            do {
                                                myProfile2223.deleteChild(myProfile2223.getChildren().get(0));
                                            } while (myProfile2223.getChildren().size() > 0);
                                            for (int ii = 0; ii < 子嗣.size(); ii++) {
                                                TreeNode cur = 子嗣.get(ii);
                                                myProfile2223.addChild(cur);
                                            }
                                            currootnode.setViewHolder(new SelectableHeaderHolder(getActivity()));
                                            ((CustomViewHolderFragment888) inout.get(inout.size() - 1)).mainformthis.finish();
                                            inout.remove(inout.size() - 1);
                                            MainActivity.curroot = myProfile2223;
                                            MainActivity.curroot000 = curroot;
                                            Intent iii = new Intent(getActivity(), SingleFragmentActivity.class);
                                            iii.putExtra(SingleFragmentActivity.FRAGMENT_PARAM, CustomViewHolderFragment888.class);
                                            ((CustomViewHolderFragment888) inout.get(inout.size() - 1)).mainformthis.startActivity(iii);

                                            final TreeNode finalMyProfile22 = myProfile222;
                                            new Handler().postDelayed(new Runnable() {
                                                @Override
                                                public void run() {
                                                    if (MainActivity.curroot.equals(finalMyProfile22)) {

                                                    } else {
                                                        if (currootnode.isLeaf()) {
                                                            MainActivity.curroot = finalMyProfile22;
                                                        } else {
                                                            MainActivity.curroot = currootnode;
                                                        }
                                                        MainActivity.curroot000 = curroot;
                                                        Intent iii = new Intent(((CustomViewHolderFragment888) inout.get(inout.size() - 1)).mainformthis, SingleFragmentActivity.class);
                                                        iii.putExtra(SingleFragmentActivity.FRAGMENT_PARAM, CustomViewHolderFragment888.class);
                                                        ((CustomViewHolderFragment888) inout.get(inout.size() - 1)).mainformthis.startActivity(iii);
                                                    }

                                                }
                                            }, 500);
                                            return;
                                        } else {
                                            currootnode.addChild(myProfile);
                                        }
                                        final TreeNode finalMyProfile22 = myProfile222;
                                        new Handler().postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                if (MainActivity.curroot.equals(finalMyProfile22)) {

                                                } else {
                                                    ((CustomViewHolderFragment888) inout.get(inout.size() - 1)).mainformthis.finish();

                                                    inout.remove(inout.size() - 1);
                                                    if (currootnode.isLeaf()) {
                                                        MainActivity.curroot = finalMyProfile22;
                                                    } else {
                                                        MainActivity.curroot = currootnode;
                                                    }
                                                    MainActivity.curroot000 = curroot;
                                                    Intent iii = new Intent(((CustomViewHolderFragment888) inout.get(inout.size() - 1)).mainformthis, SingleFragmentActivity.class);
                                                    iii.putExtra(SingleFragmentActivity.FRAGMENT_PARAM, CustomViewHolderFragment888.class);

                                                    ((CustomViewHolderFragment888) inout.get(inout.size() - 1)).mainformthis.startActivity(iii);
                                                }

                                            }
                                        }, 500);


                                    }
                                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        // TODO Auto-generated method stub


                                    }
                                })
                                .create();
                        alertDialog.show();
                    }

                    if (items[i].equals("添加兄长")) {//"编辑名字","添加子嗣","插入兄长","编辑备注","删除子树""添加弟弟"
                        final EditText etView = new EditText(getActivity());//创建一个imageView对象
                        etView.setText("长兄名" + finalNodetext);
                        AlertDialog alertDialog = new AlertDialog
                                .Builder(getActivity())
                                .setView(etView)
                                .setTitle("添加兄长")
                                .setMessage(finalNodetext)
                                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        String www = null;
                                        int jj = 0;
                                        String vid = null;
                                        //ArrayList<String> 子嗣save = final子嗣;
                                        ArrayList<String> 子嗣save = new ArrayList();
                                        ArrayList<String> 附加save = new ArrayList();
                                        for (int i = 0; i < final子嗣.size(); i++) {
                                            www = final子嗣.get(i).toString();
                                            // www=www.replaceAll("<","");
                                            //www=www.replaceAll(">","");

                                            jj = getdeep(www);
                                            vid = www.substring(0, jj);
                                            www = www.substring(jj);
                                            if (finalvid.equals(vid)) {
                                                子嗣save.add(vid.substring(0, vid.length() - 2) + pu0(currootnode.getParent().getChildren().size() + 1) + etView.getText().toString());
                                                //子嗣save.add(final子嗣.get(i).toString().replace(finalNodetext, etView.getText().toString()));
                                                附加save.add(vid.substring(0, vid.length() - 2) + pu0(currootnode.getParent().getChildren().size() + 1));
                                                子嗣save.add(final子嗣.get(i).toString());
                                                附加save.add(final附加.get(i).toString());
                                            } else {
                                                子嗣save.add(final子嗣.get(i).toString());
                                                附加save.add(final附加.get(i).toString());
                                            }
                                        }
                                        try {
                                            save(子嗣save, finalVpath + "/子嗣.txt");
                                            save(附加save, finalVpath + "/附加.txt");
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        } finally {
                                        }

                                        TreeNode myProfile222 = currootnode.getParent();

                                        TreeNode myProfile = null;


                                        myProfile = new TreeNode(etView.getText().toString()).setViewHolder(new SelectableItemHolder(getActivity()));
                                        myProfile.ftext2 = finalvid.substring(0, finalvid.length() - 2) + pu0(currootnode.getParent().getChildren().size() + 1);
                                        myProfile.ftext3 = finalVpath + "/图片/" + myProfile.ftext2 + ".jpg";
                                        ;

                                        ArrayList<TreeNode> 子嗣 = new ArrayList<>();
                                        int tmpcc = myProfile222.getChildren().size();
                                        for (int ii = 0; ii < tmpcc; ii++) {
                                            TreeNode cur = myProfile222.getChildren().get(ii);
                                            if (cur.equals(currootnode)) {
                                                子嗣.add(myProfile);
                                                //myProfile222.deleteChild(curroot);
                                                子嗣.add(cur);
                                            } else {
                                                子嗣.add(cur);
                                                //myProfile222.deleteChild(cur);
                                            }

                                        }
                                        do {
                                            myProfile222.deleteChild(myProfile222.getChildren().get(0));
                                        } while (myProfile222.getChildren().size() > 0);
                                        for (int ii = 0; ii < 子嗣.size(); ii++) {
                                            TreeNode cur = 子嗣.get(ii);
                                            myProfile222.addChild(cur);
                                        }

                                        getActivity().finish();
                                        inout.remove(inout.size() - 1);
                                        MainActivity.curroot = myProfile222;
                                        MainActivity.curroot000 = curroot;
                                        Intent iii = new Intent(getActivity(), SingleFragmentActivity.class);
                                        iii.putExtra(SingleFragmentActivity.FRAGMENT_PARAM, CustomViewHolderFragment888.class);
                                        getActivity().startActivity(iii);

                                    }
                                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        // TODO Auto-generated method stub


                                    }
                                })
                                .create();

                        alertDialog.show();

                    }
                    if (items[i].
                            equals("添加弟弟")) {//"编辑名字","添加子嗣","插入兄长","编辑备注","删除子树""添加弟弟"
                        final EditText etView = new EditText(getActivity());//创建一个imageView对象
                        etView.setText("添加弟弟名" + finalNodetext);
                        AlertDialog alertDialog = new AlertDialog
                                .Builder(getActivity())
                                .setView(etView)
                                .setTitle("添加弟弟")
                                .setMessage(finalNodetext)
                                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        String www = null;
                                        int jj = 0;
                                        String vid = null;
                                        //ArrayList<String> 子嗣save = final子嗣;
                                        ArrayList<String> 子嗣save = new ArrayList();
                                        ArrayList<String> 附加save = new ArrayList();
                                        for (int i = 0; i < final子嗣.size(); i++) {
                                            www = final子嗣.get(i).toString();
                                            // www=www.replaceAll("<","");
                                            //www=www.replaceAll(">","");

                                            jj = getdeep(www);
                                            vid = www.substring(0, jj);
                                            www = www.substring(jj);
                                            //if (finalvid.equals(vid)) {
                                            if (vid.indexOf(finalvid) == 0) {
                                                子嗣save.add(final子嗣.get(i).toString());
                                                附加save.add(final附加.get(i).toString());
                                                if (((i == final子嗣.size() - 1))) {
                                                    子嗣save.add(vid.substring(0, vid.length() - 2) + pu0(currootnode.getParent().getChildren().size() + 1) + etView.getText().toString());
                                                    附加save.add(vid.substring(0, vid.length() - 2) + pu0(currootnode.getParent().getChildren().size() + 1));
                                                } else {
                                                    if (((final子嗣.get(i + 1).substring(0, getdeep(final子嗣.get(i + 1))).indexOf(finalvid) != 0) || (i == final子嗣.size() - 1))) {
                                                        子嗣save.add(vid.substring(0, vid.length() - 2) + pu0(currootnode.getParent().getChildren().size() + 1) + etView.getText().toString());
                                                        附加save.add(vid.substring(0, vid.length() - 2) + pu0(currootnode.getParent().getChildren().size() + 1));
                                                    }
                                                }
                                            } else {
                                                子嗣save.add(final子嗣.get(i).toString());
                                                附加save.add(final附加.get(i).toString());
                                            }
                                        }
                                        try {
                                            save(子嗣save, finalVpath + "/子嗣.txt");
                                            save(附加save, finalVpath + "/附加.txt");
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        } finally {
                                        }

                                        TreeNode myProfile222 = currootnode.getParent();

                                        TreeNode myProfile = null;


                                        myProfile = new TreeNode(etView.getText().toString()).setViewHolder(new SelectableItemHolder(getActivity()));
                                        myProfile.ftext2 = finalvid.substring(0, finalvid.length() - 2) + pu0(currootnode.getParent().getChildren().size() + 1);

                                        myProfile.ftext3 = finalVpath + "/图片/" + myProfile.ftext2 + ".jpg";
                                        ;

                                        ArrayList<TreeNode> 子嗣 = new ArrayList<>();
                                        int tmpcc = myProfile222.getChildren().size();
                                        for (int ii = 0; ii < tmpcc; ii++) {
                                            TreeNode cur = myProfile222.getChildren().get(ii);
                                            if (cur.equals(currootnode)) {

                                                子嗣.add(cur);
                                                子嗣.add(myProfile);
                                            } else {
                                                子嗣.add(cur);

                                            }

                                        }
                                        do {
                                            myProfile222.deleteChild(myProfile222.getChildren().get(0));
                                        } while (myProfile222.getChildren().size() > 0);
                                        for (int ii = 0; ii < 子嗣.size(); ii++) {
                                            TreeNode cur = 子嗣.get(ii);
                                            myProfile222.addChild(cur);
                                        }

                                        getActivity().finish();
                                        inout.remove(inout.size() - 1);
                                        MainActivity.curroot = myProfile222;
                                        MainActivity.curroot000 = curroot;
                                        Intent iii = new Intent(getActivity(), SingleFragmentActivity.class);
                                        iii.putExtra(SingleFragmentActivity.FRAGMENT_PARAM, CustomViewHolderFragment888.class);
                                        getActivity().startActivity(iii);

                                    }
                                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        // TODO Auto-generated method stub


                                    }
                                })
                                .create();

                        alertDialog.show();

                    }
                    if (items[i].
                            equals("编辑备注")) {//"编辑名字","添加子嗣","插入兄长","编辑备注","删除子树"
                        final EditText etView = new EditText(getActivity());//创建一个imageView对象
                        etView.setText(final原来备注);
                        AlertDialog alertDialog = new AlertDialog
                                .Builder(getActivity())
                                .setView(etView)
                                .setTitle("编辑备注:" + finalNodetext)
                                .setMessage(final原来备注)
                                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        String www = null;
                                        int jj = 0;
                                        String vid = null;
                                        //ArrayList<String> 子嗣save = final子嗣;
                                        ArrayList<String> 附加save = new ArrayList();
                                        for (int i = 0; i < final附加.size(); i++) {
                                            www = final附加.get(i).toString();
                                            // www=www.replaceAll("<","");
                                            //www=www.replaceAll(">","");

                                            jj = getdeep(www);
                                            vid = www.substring(0, jj);
                                            www = www.substring(jj);
                                            if (finalvid.equals(vid)) {

                                                附加save.add(finalvid + etView.getText().toString());
                                            } else {
                                                附加save.add(final附加.get(i).toString());
                                            }
                                        }
                                        try {
                                            save(附加save, finalVpath + "/附加.txt");
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        } finally {
                                        }


                                    }
                                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        // TODO Auto-generated method stub


                                    }
                                })
                                .create();

                        alertDialog.show();

                    }
                    if (items[i].
                            equals("删除子树")) {//"编辑名字","添加子嗣","插入兄长","编辑备注","删除子树"
                        final EditText etView = new EditText(getActivity());//创建一个imageView对象
                        etView.setText("删除子树:" + finalNodetext + ",是否确定删除子树？");
                        AlertDialog alertDialog = new AlertDialog
                                .Builder(getActivity())
                                .setView(etView)
                                .setTitle("删除子树")
                                .setMessage(finalNodetext)
                                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        String www = null;
                                        int jj = 0;
                                        String vid = null;

                                        ArrayList<String> 子嗣save = new ArrayList();
                                        ArrayList<String> 附加save = new ArrayList();
                                        File subf = null;//finalVpath+"\"+vid;
                                        for (int i = 0; i < final子嗣.size(); i++) {
                                            www = final子嗣.get(i).toString();
                                            // www=www.replaceAll("<","");
                                            //www=www.replaceAll(">","");
                                            jj = getdeep(www);
                                            vid = www.substring(0, jj);
                                            www = www.substring(jj);
                                            if (vid.indexOf(finalvid) == 0) {
                                                subf = new File(finalVpath + "/" + vid);
                                                if (!subf.exists()) {
                                                } else {
                                                    DelFileAll(subf);
                                                }
                                                subf = new File(finalVpath + "/图片/" + vid + ".jpg");
                                                if (!subf.exists()) {
                                                } else {
                                                    subf.delete();
                                                }
                                                subf = new File(finalVpath + "/图片/" + vid + ".png");
                                                if (!subf.exists()) {
                                                } else {
                                                    subf.delete();
                                                }
                                            } else {
                                                子嗣save.add(final子嗣.get(i).toString());
                                                附加save.add(final附加.get(i).toString());
                                            }
                                        }
                                        if (子嗣save.size() == 0) {
                                            subf = new File(finalVpath);
                                            if (!subf.exists()) {

                                            } else {

                                                DelFileAll(subf);
                                            }


                                        } else {
                                            try {
                                                save(子嗣save, finalVpath + "/子嗣.txt");
                                                save(附加save, finalVpath + "/附加.txt");
                                            } catch (IOException e) {
                                                e.printStackTrace();
                                            } finally {
                                            }
                                        }
                                        TreeNode myProfile222 = null;

                                        myProfile222 = currootnode.getParent();


                                        if (myProfile222.getChildren().size() == 1) {

                                            TreeNode myProfilepp = currootnode.getParent().getParent();

                                            IconTreeItemHolder.IconTreeItem curitem = (IconTreeItemHolder.IconTreeItem) currootnode.getParent().getValue();

                                            TreeNode myProfilep = null;


                                            myProfilep = new TreeNode(curitem.text).setViewHolder(new SelectableItemHolder(getActivity()));
                                            myProfilep.ftext2 = currootnode.getParent().ftext2;
                                            myProfilep.ftext3 = currootnode.getParent().ftext3;
                                            ArrayList<TreeNode> 子嗣 = new ArrayList<>();
                                            int tmpcc = myProfilepp.getChildren().size();
                                            for (int ii = 0; ii < tmpcc; ii++) {
                                                TreeNode cur = myProfilepp.getChildren().get(ii);
                                                if (cur.equals(currootnode.getParent())) {
                                                    子嗣.add(myProfilep);
                                                } else {
                                                    子嗣.add(cur);
                                                }
                                            }
                                            do {
                                                myProfilepp.deleteChild(myProfilepp.getChildren().get(0));
                                            } while (myProfilepp.getChildren().size() > 0);
                                            for (int ii = 0; ii < 子嗣.size(); ii++) {
                                                TreeNode cur = 子嗣.get(ii);
                                                myProfilepp.addChild(cur);
                                            }
                                            myProfile222 = myProfilepp;
                                            MainActivity.curroot = myProfile222;
                                            MainActivity.curroot000 = curroot;
                                            currootnode.getParent().deleteChild(currootnode);

                                            TreeNode nownode = curroot;

                                            try {

                                                ((CustomViewHolderFragment888) inout.get(inout.size() - 1)).mainformthis.finish();
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            } finally {
                                            }
                                            try {
                                                MainActivity.inout.remove(MainActivity.inout.size() - 1);
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            } finally {
                                            }
                                            try {

                                                ((CustomViewHolderFragment888) inout.get(inout.size() - 1)).mainformthis.finish();
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            } finally {
                                            }
                                            try {
                                                MainActivity.inout.remove(MainActivity.inout.size() - 1);
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            } finally {
                                            }
                                            Intent iii = new Intent(getActivity(), SingleFragmentActivity.class);
                                            iii.putExtra(SingleFragmentActivity.FRAGMENT_PARAM, CustomViewHolderFragment888.class);

                                            ((Fragment) MainActivity.inout.get(MainActivity.inout.size() - 1)).getActivity().startActivity(iii);


                                        } else {
                                            myProfile222.deleteChild(currootnode);

                                            //getActivity().finish();
                                            ((Fragment) MainActivity.inout.get(MainActivity.inout.size() - 1)).getActivity().finish();
                                            inout.remove(inout.size() - 1);
                                            MainActivity.curroot = myProfile222;
                                            MainActivity.curroot000 = curroot;
                                            Intent iii = new Intent(getActivity(), SingleFragmentActivity.class);
                                            iii.putExtra(SingleFragmentActivity.FRAGMENT_PARAM, CustomViewHolderFragment888.class);
                                            ((Fragment) MainActivity.inout.get(MainActivity.inout.size() - 1)).getActivity().startActivity(iii);
                                        }


                                        ;

                                    }
                                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        // TODO Auto-generated method stub


                                    }
                                })
                                .create();

                        alertDialog.show();

                    }
                    if (items[i].
                            equals("插入/修改图片")) {//"编辑名字","添加子嗣","插入兄长","编辑备注","删除子树"
                        String tmp = finalVpath + "/图片/" + finalvid;
                        tmpPicturePath = tmp;
                        Intent intent = new Intent(Intent.ACTION_PICK, null);
                        intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
                        startActivityForResult(intent, 2);

                    }
                }
            });
            alertBuilder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {
                    // TODO Auto-generated method stub
                    dialog.dismiss();
                }
            });

            alertDialog1 = alertBuilder.create();
            alertDialog1.show();
            return true;
        }

    };

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2) {

            if (data != null) {
                // 得到图片的全路径
                Uri uri = data.getData();

                ImageView imageView = new ImageView(getActivity());//创建一个imageView对象
                imageView.setImageURI(uri);

                Bitmap bm = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
                saveImageFile(bm);
            }
        }
    }

    public String saveImageFile(Bitmap bitmap) {
        FileOutputStream out = null;
        String filename = tmpPicturePath + ".jpg";

        File file = new File(filename.substring(0, filename.lastIndexOf("/")));
        //File filePath=new File(file.getPath());
        if (!file.exists()) {
            // file.mkdir();
            file.mkdirs();
        }
        try {
            out = new FileOutputStream(filename);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return filename;
    }

    public static void DelFileAll(File file) {

        File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                File photoFile = new File(files[i].getPath());
                photoFile.delete();
            }
            if (files[i].isDirectory()) {
                DelFileAll(files[i]);
            }
        }
        file.delete();
    }

    public String pu0(int iii) {
        String www = null;
        if (iii < 10) {
            www = "0" + iii;
        } else {
            www = (iii + "");
        }

        return www;
    }

    public void save(ArrayList<String> users, String filename) throws FileNotFoundException {
        String tmp = users.toString().replaceAll(",", "\n").replaceAll("\\[", "").replaceAll("]", "").replaceAll(" ", "");
        PrintWriter pw = new PrintWriter(new FileOutputStream(filename));
        pw.write(tmp);
        pw.close();
    }

    public void SaveFile(ArrayList<String> users, String filename) throws IOException {

        File file = new File(filename);
        //创建文件输出流
        FileOutputStream fos = new FileOutputStream(file);
        //创建对象输出流
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        //保存对象
        oos.writeObject(users);
    }

    /**
     * 图片的复制操作方法
     *
     * @param fromFile 被复制的图片
     * @param toFile   复制的目录图片
     */
    public static void copyfile(File fromFile, File toFile) {

        if (!fromFile.exists()) {

            return;
        }

        if (!fromFile.isFile()) {
            return;
        }

        if (!fromFile.canRead()) {
            return;
        }

        if (!toFile.getParentFile().exists()) {

            toFile.getParentFile().mkdirs();

        }

        if (toFile.exists()) {

            toFile.delete();

        }

        try {

            FileInputStream fosfrom = new FileInputStream(fromFile);

            FileOutputStream fosto = new FileOutputStream(toFile);

            byte[] bt = new byte[1024];

            int c;

            while ((c = fosfrom.read(bt)) > 0) {

                fosto.write(bt, 0, c);

            }
            //关闭输入、输出流
            fosfrom.close();

            fosto.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();

        }

    }


}

package lijunyu.qq165442523.mounthuali.fragment;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.unnamed.b.atv.model.TreeNode;
import com.unnamed.b.atv.view.AndroidTreeView;

import java.io.File;
import java.net.URISyntaxException;
import java.util.ArrayList;

import lijunyu.qq165442523.mounthuali.R;
import lijunyu.qq165442523.mounthuali.activity.MainActivity;
import lijunyu.qq165442523.mounthuali.activity.SingleFragmentActivity;
import lijunyu.qq165442523.mounthuali.holder.HeaderHolder;
import lijunyu.qq165442523.mounthuali.holder.IconTreeItemHolder;
import lijunyu.qq165442523.mounthuali.holder.SelectableHeaderHolder;
import lijunyu.qq165442523.mounthuali.holder.SelectableItemHolder;

import static android.content.Intent.getIntent;

/**
 * Created by Bogdan Melnychuk on 2/12/15.
 */
public class CustomViewHolderFragment666 extends Fragment {
    private AndroidTreeView tView;
    public TreeNode 仲荣 = null;
    ArrayList<String> songIDs = new ArrayList<>();
    public String path0 = null;
    public int level0 = 0;
    public TextView sb = null;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

            //Intent intent = getIntent("");
            //path0 = (String)intent.getStringExtra("path0");
            //level0 = Integer.parseInt((String)intent.getStringExtra("level0"));
            path0=MainActivity.path0;
            level0= MainActivity.level0;

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }
    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        //回退到一世界面    回退十步
        ((MenuItem) menu.findItem(R.id.expandAll)).setTitle("打开 3 层");
        ((MenuItem) menu.findItem(R.id.collapseAll)).setTitle("全部收缩");
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.expandAll:
                // tView.expandAll();

                tView.expandLevel(3);
                //tView.expandLevel(9);

                //   tView.expandNode(仲荣);
                //  tView.toggleNode(仲荣);
//                仲荣.setExpanded(true);
                // tView.selectNode(仲荣,true);
                break;

            case R.id.collapseAll:
                tView.collapseAll();
                break;
        }
        return true;
    }

    public static int getdeep(String oneline) {
        for (int i = 1; i < oneline.length(); i++) {
            if ("0123456789".indexOf(oneline.charAt(i)) == -1) {
                return i;
            }
        }
        return -1;

    }

    public int tree(TreeNode node, String curroot) {

        ArrayList<String> songIDs = MainActivity.readTxt2(curroot + "/子嗣.txt");
        String www = "";
        String vid = "";
        TreeNode cur0 = null;
        TreeNode cur = null;
        TreeNode temp0 = null;
        TreeNode vParentNode = node;
        //node.getParent().setExpanded(false);
        //tView = new AndroidTreeView(getActivity(), root);
        tView.collapseNode(node.getParent());
        node.deleteChild(node.getChildren().get(0));
        int jj0 = 2;
        int jj = 2;
        for (int i = 0; i < songIDs.size(); i++) {
            if (i == songIDs.size() - 2) {
                www = "www";
            }
            www = songIDs.get(i).toString();
            // www=www.replaceAll("<","");
            //www=www.replaceAll(">","");

            jj = getdeep(www);
            vid = www.substring(0, jj);
            www = www.substring(jj);
            if (jj == 3) {
                jj = 2;
            }

            boolean ishavechild = false;
            if ((new File(curroot + "/" + vid)).exists()) {
                ishavechild = true;
            }
            if (i >= (songIDs.size() - 1)) {
                ishavechild = false;
            } else {
                if (getdeep(songIDs.get(i + 1).toString()) == (jj + 2)) {
                    ishavechild = true;
                }
            }
            if (ishavechild) {//////ic_people  ic_person
                cur = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, www)).setViewHolder(new SelectableHeaderHolder(getActivity()));
            } else {
                cur = new TreeNode(www).setViewHolder(new SelectableItemHolder(getActivity()));
            }
            cur.ftext2 = vid;
            if (jj == jj0) {
                vParentNode.addChild(cur);
                     jj0 = jj;
                cur0 = cur;
            }
            if (jj - jj0 == 2) {
                vParentNode = cur0;
                vParentNode.addChild(cur);

                jj0 = jj;
                cur0 = cur;
            }
            if (jj < jj0) {
                for (int iFinish = 0; iFinish < Math.floor((jj0 - jj) / 2); iFinish++) {
                    vParentNode = vParentNode.getParent();
                }
                vParentNode.addChild(cur);

                jj0 = jj;
                cur0 = cur;
            }
            String ppp = curroot + "/图片/" + vid + ".jpg";
            cur.ftext3 = ppp;
            ppp = curroot + "/" + vid;
            File file = new File(ppp);
            if (file.exists()) {
                 temp0 = new TreeNode("...").setViewHolder(new SelectableItemHolder(getActivity()));
                temp0.ftext2 = ppp;
                cur.addChild(temp0);

            }

        }
        //node.getParent().setExpanded(true);
        tView.expandNode(node.getParent());
        return 1;

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_default, null, false);
        final ViewGroup containerView = (ViewGroup) rootView.findViewById(R.id.container);
        rootView.findViewById(R.id.status_bar).setVisibility(View.VISIBLE);
        sb = rootView.findViewById(R.id.status_bar);
        if (level0 == 0) {
            sb.setText("");
        } else {
            sb.setText(path0);
        }

        final TreeNode root = TreeNode.root();
        String www = "";
        TreeNode myProfile = MainActivity.curroot;

        if (MainActivity.curroot.isLeaf()) {
            www = MainActivity.curroot.getValue().toString();
            myProfile = new TreeNode(www).setViewHolder(new SelectableItemHolder(getActivity()));
        } else {

            IconTreeItemHolder.IconTreeItem curitem = (IconTreeItemHolder.IconTreeItem) MainActivity.curroot.getValue();
            www = curitem.text;
            myProfile = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, www));
            myProfile.setViewHolder(new HeaderHolder(getActivity()));
        }
        myProfile.ftext2=MainActivity.curroot.ftext2;
        myProfile.ftext3=MainActivity.curroot.ftext3;
        copyChildTree(MainActivity.curroot, myProfile);

        root.addChild(myProfile);
        tView = new AndroidTreeView(getActivity(), root);
        tView.setDefaultAnimation(true);

        tView.setDefaultContainerStyle(R.style.TreeNodeStyleCustom, true);

        tView.setDefaultNodeClickListener(nodeClickListener);
        tView.setDefaultNodeLongClickListener(nodeLongClickListener);
        containerView.addView(tView.getView());
        if (MainActivity.curroot == null) {
            tView.expandLevel(3);
        }
        if (savedInstanceState != null) {
            String state = savedInstanceState.getString("tState");
            if (!TextUtils.isEmpty(state)) {
                tView.restoreState(state);
            }
        }

        return rootView;
    }

    private void copyChildTree(TreeNode fromroot, TreeNode toroot) {
        String www = "";
        if (fromroot.isLeaf()) {

        } else {
            for (int i = 0; i < fromroot.getChildren().size(); i++) {
                TreeNode cur = fromroot.getChildren().get(i);
                if (cur.isLeaf()) {
                    www = cur.getValue().toString();
                    TreeNode myProfile = new TreeNode(www).setViewHolder(new SelectableItemHolder(getActivity()));
                    myProfile.ftext2=cur.ftext2;
                    myProfile.ftext3=cur.ftext3;
                    toroot.addChild(myProfile);
                    copyChildTree(cur,myProfile);
                } else {

                    IconTreeItemHolder.IconTreeItem curitem = (IconTreeItemHolder.IconTreeItem) cur.getValue();
                    www = curitem.text;
                    TreeNode myProfile = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, www));
                    myProfile.setViewHolder(new HeaderHolder(getActivity()));
                    myProfile.ftext2=cur.ftext2;
                    myProfile.ftext3=cur.ftext3;
                    toroot.addChild(myProfile);
                    copyChildTree(cur,myProfile);
                }
            }

        }


    }



    private TreeNode.TreeNodeClickListener nodeClickListener = new TreeNode.TreeNodeClickListener() {
        @Override
        public void onClick(TreeNode node, Object value) {


        }
    };

    private TreeNode.TreeNodeLongClickListener nodeLongClickListener = new TreeNode.TreeNodeLongClickListener() {
        @Override
        public boolean onLongClick(TreeNode node, Object value) {
            if (node.getLevel() < 2) {
                Toast.makeText(getActivity(), "根节点以下才可弹出菜单信息 ", Toast.LENGTH_SHORT).show();
                return true;
            }
            String nodetext = "";
            if (node.isLeaf()) {
                nodetext = value.toString();
            } else {
                IconTreeItemHolder.IconTreeItem item = (IconTreeItemHolder.IconTreeItem) value;
                nodetext = item.text;
            }
            //Toast.makeText(getActivity(), "Long click: " + item.text, Toast.LENGTH_SHORT).show();
            AlertDialog alertDialog1; //信息框
            String 打开相关图片 = "";
            String 第n世 = "";
            String 备注 = "备注:";
            String 认祖归宗 = "认祖归宗：";
            {
                if (node.isLeaf()) {
                    第n世 = "第" + (node.getLevel() +level0-1) + "世 有子嗣 0 人" + " 兄弟共 " + node.getParent().getChildren().size() + "人";
                } else {
                    第n世 = "第" + (node.getLevel() +level0-1) + "世 有子嗣 " + node.getChildren().size() + " 人" + " 兄弟共 " + node.getParent().getChildren().size() + "人";
                }
                for (int ijk = 0; ijk < node.getParent().getChildren().size(); ijk++) {
                    if (node.getParent().getChildren().get(ijk).equals(node)) {
                        第n世 = 第n世 + " 在兄弟中排行第 " + (ijk + 1);
                    }
                }
            }
            第n世 = "③" + 第n世 + " 说明：子嗣数是动态统计，如果显示0，也可能是没有录入数据之因，特此说明。 ";
            /////////////////////////////////////
            ArrayList<String> 子嗣 = null;
            ArrayList<String> 附加 = null;
            String vpath = node.ftext3;
            vpath = vpath.replace("/图片/", "/");
            vpath = vpath.substring(0, vpath.lastIndexOf("/"));
            // vpath=vpath+"/子嗣.txt";
            子嗣 = MainActivity.readTxt2(vpath + "/子嗣.txt");
            String www = "";
            String vid = "";
            String vvid = "";
            int jj0 = 2;
            int jj = 2;
            for (int i = 0; i < 子嗣.size(); i++) {
                www = 子嗣.get(i).toString();
                // www=www.replaceAll("<","");
                //www=www.replaceAll(">","");
                if (www.equals("03030402寿官")) {
                    www = "03030402温";
                }
                if (www.equals("030302福隆<徒>")) {
                    www = "030302<徙>2016年已认祖归宗";
                }
                jj = getdeep(www);
                vid = www.substring(0, jj);
                www = www.substring(jj);
                if (nodetext.equals(www)) {
                    break;
                }
            }

            vid = node.ftext2;
            附加 = MainActivity.readTxt2(vpath + "/附加.txt");
            www = "";
            vvid = "";
            jj0 = 2;
            jj = 2;
            for (int i = 0; i < 附加.size(); i++) {
                www = 附加.get(i).toString();
                // www=www.replaceAll("<","");
                //www=www.replaceAll(">","");
                if (www.equals("03030402寿官")) {
                    www = "03030402温";
                }
                if (www.equals("030302福隆<徒>")) {
                    www = "030302<徙>2016年已认祖归宗";
                }
                jj = getdeep(www);
                vvid = www.substring(0, jj);
                www = www.substring(jj);
                if (vid.equals(vvid)) {
                    备注 = "④备注:" + www;
                    break;
                }
            }
            //vvid = node.ftext2;
            /////////////////////////////////////////
            认祖归宗 = "⑤认祖归宗：";
            String 认祖归宗0="";
            if (nodetext.indexOf("<") > 0) {
                认祖归宗 = 认祖归宗 + nodetext.substring(0, nodetext.indexOf("<")) + "->";
            }else{
                认祖归宗 = 认祖归宗 + nodetext + "->";
            }
            TreeNode curnode = node.getParent();
            IconTreeItemHolder.IconTreeItem curitem = (IconTreeItemHolder.IconTreeItem) curnode.getValue();
            //while (!curitem.text.equals("黄帝")) {
            while (!node.getRoot().equals(curnode)) {
                if (curitem.text.indexOf("<") > 0) {
                    认祖归宗 = 认祖归宗 + curitem.text.substring(0, curitem.text.indexOf("<")) + "->";
                    认祖归宗0 = 认祖归宗0 + curitem.text.substring(0, curitem.text.indexOf("<")) + "->";
                } else {
                    认祖归宗 = 认祖归宗 + curitem.text + "->";
                    认祖归宗0 = 认祖归宗0 + curitem.text + "->";
                }
                curnode = curnode.getParent();
                curitem = (IconTreeItemHolder.IconTreeItem) curnode.getValue();
            }
            //curitem = (IconTreeItemHolder.IconTreeItem) curnode.getValue();
            //认祖归宗 = 认祖归宗 + curitem.text;
            认祖归宗 = 认祖归宗 + path0;
            认祖归宗0 = 认祖归宗0 + path0;
            认祖归宗 = 认祖归宗.replace("仲荣->晟->黄帝", "仲荣...晟...黄帝");
            认祖归宗0 = 认祖归宗0.replace("仲荣->晟->黄帝", "仲荣...晟...黄帝");

            final String ppp = node.ftext3;
            File dir = new File(ppp);
            if (!dir.exists()) {
                打开相关图片 = "② 找不到相关图片";
            } else {
                打开相关图片 = "② 打开相关图片";
            }
            final String[] items = {"①作为根节点打开", 打开相关图片, 第n世, 备注, 认祖归宗};
            AlertDialog.Builder alertBuilder = new AlertDialog.Builder(getActivity());
            alertBuilder.setTitle("【" + nodetext + "】");
            final TreeNode curroot = node;
            final String 认祖归宗00=认祖归宗0.replace("⑤认祖归宗：","");

            alertBuilder.setItems(items, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (items[i].equals("② 打开相关图片")) {
                        //Toast.makeText(getActivity(), "【打开相关图片】功能还在开发中...", Toast.LENGTH_SHORT).show();

                        File file = new File(ppp);
                        if (!file.exists()) {
                            return;
                        }
                        try {

                            ImageView imageView = new ImageView(getActivity());//创建一个imageView对象
                            if (file.exists()) {
                                Bitmap bm = BitmapFactory.decodeFile(ppp);

                                imageView.setImageBitmap(bm);

                                AlertDialog alertDialog = new AlertDialog
                                        .Builder(getActivity())
                                        .setView(imageView)
                                        .create();

                                alertDialog.show();


                            }


                        } catch (Exception e) {
                            Toast.makeText(getActivity(), "已找到图片，但无法显示", Toast.LENGTH_SHORT).show();

                        }
                    }
                    if (items[i].equals("①作为根节点打开")) {
                        //Toast.makeText(getActivity(), "①作为根节点打开", Toast.LENGTH_SHORT).show();
                        MainActivity.curroot=curroot;
                        Intent iii = new Intent(getActivity(), SingleFragmentActivity.class);
                        iii.putExtra(SingleFragmentActivity.FRAGMENT_PARAM, CustomViewHolderFragment666.class);
                        iii.putExtra("path0", 认祖归宗00);
                        iii.putExtra("level0", curroot.getLevel()+level0-1 );
                        MainActivity.path0=认祖归宗00;
                        MainActivity.level0=curroot.getLevel()+level0-1 ;
                        getActivity().startActivity(iii);


                    }

                }
            });
            alertBuilder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {
                    // TODO Auto-generated method stub
                    dialog.dismiss();
                }
            });


            alertDialog1 = alertBuilder.create();
            alertDialog1.show();
            return true;
        }
    };

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("tState", tView.getSaveState());
    }
}

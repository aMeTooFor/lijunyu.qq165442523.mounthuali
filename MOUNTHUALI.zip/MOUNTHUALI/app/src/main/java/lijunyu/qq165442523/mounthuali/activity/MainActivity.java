package lijunyu.qq165442523.mounthuali.activity;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBarActivity;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.unnamed.b.atv.model.TreeNode;

import lijunyu.qq165442523.mounthuali.R;
import lijunyu.qq165442523.mounthuali.fragment.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;


public class MainActivity extends ActionBarActivity {
    public static Activity mainform;
    public static Fragment firstform = null;
    public String DB_PATH;
    public static TreeNode curroot = null;
    public static TreeNode curroot000 = null;
    public static String path0 = null;
    public static int level0 = 0;
    public static ArrayList<Fragment> inout = new ArrayList<>();
    public static Bundle savedInstanceState = new Bundle();

    /**
     * 显示导航栏的虚拟menu键
     */
    private void showNagtiveMenu() {
        int menuFlag = 0;
        try {
            menuFlag = WindowManager.LayoutParams.class.getField("FLAG_NEEDS_MENU_KEY").getInt(null);
            Window window = getWindow();
            window.addFlags(menuFlag);
            return;
        } catch (NoSuchFieldException e) {
            //Log.e(LOGTAG, "NoSuchFieldException : " + e.getLocalizedMessage().toString() );
        } catch (IllegalAccessException e) {
            // Log.e(LOGTAG, "IllegalAccessException : " + e.getLocalizedMessage().toString() );
        } catch (Exception e) {
            //Log.e(LOGTAG, "Exception : " + e.getLocalizedMessage().toString() );
        }
        try {
            menuFlag = WindowManager.LayoutParams.class.getField("NEEDS_MENU_SET_TRUE").getInt(null);
            Method m = Window.class.getDeclaredMethod("setNeedsMenuKey", int.class);
            m.setAccessible(true);
            m.invoke(getWindow(), new Object[]{menuFlag});
        } catch (Exception e) {
            // Log.e(LOGTAG, "Exception : " + e.getLocalizedMessage().toString() );
        }
    }

    public static int gohome(int nn) {

        if (nn == 0) {
            while (inout.size() > 1) {
                try {
                    ((Fragment) inout.get(inout.size() - 1)).getActivity().finish();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                }
                try {
                    inout.remove(inout.size() - 1);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                }
            }
        } else {
            if (inout.size() < nn) {
                while (inout.size() > 1) {
                    try {
                        ((Fragment) inout.get(inout.size() - 1)).getActivity().finish();
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                    }
                    try {
                        inout.remove(inout.size() - 1);
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                    }
                }
            } else {
                int sss = inout.size() - nn;
                while (inout.size() > sss) {
                    try {
                        ((Fragment) inout.get(inout.size() - 1)).getActivity().finish();
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                    }
                    try {
                        inout.remove(inout.size() - 1);
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                    }
                }


            }

        }

        return 1;
    }



    public static void addFragment(Fragment fragment, String tag) {
        try {
            inout.add(fragment);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
    }

    private int initPermission() {
        String[] permissions = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        };

        ArrayList<String> toApplyList = new ArrayList<String>();

        for (String perm : permissions) {
            if (PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, perm)) {
                toApplyList.add(perm);
                // 进入到这里代表没有权限.

            }
        }
        String[] tmpList = new String[toApplyList.size()];
        if (!toApplyList.isEmpty()) {
            ActivityCompat.requestPermissions(this, toApplyList.toArray(tmpList), 123);
        }
        return 1;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        // 此处为android 6.0以上动态授权的回调，用户自行实现。
        //Toast toast=Toast.makeText(getApplicationContext(), permissions[iii], Toast.LENGTH_SHORT);
        //iii++;
        //toast.show();
        SharedPreferences sharedPreferencesw = getSharedPreferences("itcast", Context.MODE_PRIVATE);
        SharedPreferences.Editor editer = sharedPreferencesw.edit();
        editer.putString("initPermission", "OK");
        editer.commit();
        initData();
    }

    //该方法用于创建显示Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menuboot, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainform = MainActivity.this;
        //setOverflowShowingAlways();
        super.openOptionsMenu();
        openOptionsMenu();
        showNagtiveMenu();
        /////////////////////////////////////////////
        //verifyStoragePermissions(AWords.this);
        //if (initPermission()==0) {};
        SharedPreferences sharedPreferencesw = getSharedPreferences("itcast", Context.MODE_PRIVATE);
        //east = sharedPreferencesw.getString("east", "120");
        String initPermissionStr = sharedPreferencesw.getString("initPermission", "NOT");
        if (initPermissionStr.equals("OK")) {
            initData();
        } else {
            if (Build.VERSION.SDK_INT >= 26) {
                initPermission();
            } else {
                initData();
            }

        }

        Typeface typeFace = Typeface.createFromAsset(getAssets(), "fonts/simkai.ttf");
        try {
            // xml属性值与Typeface属性值对应
            // normal      Typeface.DEFAULT
            // sans        Typeface.SANS_SERIF
            // serif       Typeface.SERIF
            // monospace   Typeface.MONOSPACE
            Field field = Typeface.class.getDeclaredField("SERIF");
            field.setAccessible(true);
            field.set(null, typeFace);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }


    }

    public static String copyAssetFile(Context context, String fileName, String targetFilePath, boolean isoverride) {

        File dir = new File(targetFilePath);
        boolean bb = false;
        if (isoverride) {
            bb = true;
        }
        if (!isoverride) {
            if (!dir.exists()) {
                bb = true;
            }
        }
        if (bb) {
            InputStream is = null;
            FileOutputStream os = null;
            try {
                is = context.getAssets().open(fileName);
                if (!new File(targetFilePath).getParentFile().exists()) {
                    new File(targetFilePath).getParentFile().mkdirs();
                }
                os = new FileOutputStream(targetFilePath);
                byte[] buffer = new byte[1024];
                int len;
                while ((len = is.read(buffer)) != -1) {
                    os.write(buffer, 0, len);
                }
                os.flush();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (is != null)
                        is.close();
                    if (os != null)
                        os.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return targetFilePath;
    }


    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        //super.onPrepareOptionsMenu(menu);
        //回退到一世界面    回退十步
        //((MenuItem) menu.findItem(R.id.about)).setTitle("倒退回到一世");
        // ((MenuItem) menu.findItem(R.id.state)).setTitle("倒退十世");
        return super.onPrepareOptionsMenu(menu);//如果想显示菜单项,则当前方法必须返回true
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.about:
                try {
                    ImageView imageView = new ImageView(mainform);//创建一个imageView对象
                    ArrayList<String> 说明 = null;
                    说明 = MainActivity.readTxt2("/sdcard/原始氏族电子族谱/关于.txt");
                    String 说明str = 说明.toString().replaceAll("\\[", "");
                    说明str = 说明str.replaceAll("\\]", "");
                    说明str = 说明str.replaceAll(",", "\n");
                    InputStream is = getResources().openRawResource(R.raw.zfbvx);
                    Bitmap bmp = BitmapFactory.decodeStream(is);
                    imageView.setImageBitmap(bmp);
                    AlertDialog alertDialog = new AlertDialog
                            .Builder(mainform)
                            .setMessage(说明str)
                            .setView(imageView)
                            .create();

                    alertDialog.show();
                } catch (Resources.NotFoundException e) {
                    e.printStackTrace();
                }

                break;

            case R.id.state:
                //Toast.makeText(mainform, "state", Toast.LENGTH_SHORT).show();
                AlertDialog.Builder ad = new AlertDialog.Builder(mainform);
                ad.setTitle("说明");
                ArrayList<String> 说明 = null;
                说明 = MainActivity.readTxt2("/sdcard/原始氏族电子族谱/说明.txt");
                String 说明str = 说明.toString().replaceAll("\\[", "");
                说明str = 说明str.replaceAll("\\]", "");
                说明str = 说明str.replaceAll(",", "\n");
                ad.setMessage(说明str);
                ad.show();

                break;
        }
        return true;
    }


    public static ArrayList<String> readTxt2(String path) {
        ArrayList<String> songIDs = new ArrayList<>();
        try {
            File urlFile = new File(path);
            InputStreamReader isr = new InputStreamReader(new FileInputStream(urlFile), "UTF-8");
            BufferedReader br = new BufferedReader(isr);

            String line;
            while ((line = br.readLine()) != null) {
                if (!TextUtils.isEmpty(line)) {
                    songIDs.add(line);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return songIDs;
    }

    private void initData() {

        SharedPreferences sharedPreferences = getSharedPreferences("itcast", Context.MODE_PRIVATE);
        String scalestr = sharedPreferences.getString("scale", "1.0");
        int ver13 = Integer.parseInt(sharedPreferences.getString("ver13", "0"));
        if (ver13 < 3) {
            ver13++;
            SharedPreferences.Editor editer = sharedPreferences.edit();
            editer.putString("ver13", ver13 + "");
            editer.commit();
        }

        DB_PATH = "/sdcard/原始氏族电子族谱";
        File dir = new File(DB_PATH);
        if (!dir.exists()) {
            dir.mkdir();
        }
        DB_PATH = "/sdcard/原始氏族电子族谱/原始氏族";
        dir = new File(DB_PATH);
        if (!dir.exists()) {
            dir.mkdir();
        }

        copyAssetFile(mainform, "mounthuali/001.txt", DB_PATH + "/太祖.txt", false);
        if (ver13 < 3) {
            copyAssetFile(mainform, "mounthuali/002.txt", DB_PATH + "/高祖.txt", true);
        } else {
            copyAssetFile(mainform, "mounthuali/002.txt", DB_PATH + "/高祖.txt", false);
        }

        copyAssetFile(mainform, "state.txt", "/sdcard/原始氏族电子族谱/说明.txt", false);
        copyAssetFile(mainform, "about.txt", "/sdcard/原始氏族电子族谱/关于.txt", false);

        DB_PATH = "/sdcard/原始氏族电子族谱/原始氏族/世祖";
        dir = new File(DB_PATH);
        if (!dir.exists()) {
            dir.mkdir();
        }
        if (ver13 < 3) {
            copyAssetFile(mainform, "mounthuali/003/001.txt", DB_PATH + "/子嗣.txt", true);
            copyAssetFile(mainform, "mounthuali/003/002.txt", DB_PATH + "/附加.txt", true);

        } else {
            copyAssetFile(mainform, "mounthuali/003/001.txt", DB_PATH + "/子嗣.txt", false);
            copyAssetFile(mainform, "mounthuali/003/002.txt", DB_PATH + "/附加.txt", false);

        }

        DB_PATH = "/sdcard/原始氏族电子族谱/原始氏族/世祖/图片";
        dir = new File(DB_PATH);
        if (!dir.exists()) {
            dir.mkdir();
        }

        final LinkedHashMap<String, Class<?>> listItems = new LinkedHashMap<>();
        listItems.put("原始氏族电子族谱v1.0  QQ：165442523 李朝衍 2022-08-19 样式① 【长按弹出菜单】", FolderStructureFragment3.class);
        listItems.put("原始氏族电子族谱v1.0  QQ：165442523 李朝衍 2022-08-19 样式② 【层级太多最好横屏才够宽,长按弹出菜单,可将当前节点作根节点】", CustomViewHolderFragment5.class);
        listItems.put("原始氏族电子族谱v1.0  QQ：165442523 李朝衍 2022-08-19 样式③ 【长按弹出菜单,单击进入下级子嗣目录,仅仅打开一层，如果没子嗣则无反应】", CustomViewHolderFragment888.class);
        listItems.put("原始氏族电子族谱v1.0【关于】", CustomViewHolderFragment888.class);
        listItems.put("原始氏族电子族谱v1.0【说明】", CustomViewHolderFragment888.class);
        final List<String> list = new ArrayList(listItems.keySet());
        final ListView listview = (ListView) findViewById(R.id.listview);
        final SimpleArrayAdapter adapter = new SimpleArrayAdapter(mainform, list);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Class<?> clazz = listItems.values().toArray(new Class<?>[]{})[position];
                if (position == 3) {
                    //Toast.makeText(mainform, "about333", Toast.LENGTH_SHORT).show();
                    try {
                        ImageView imageView = new ImageView(mainform);//创建一个imageView对象
                        ArrayList<String> 说明 = null;
                        说明 = MainActivity.readTxt2("/sdcard/原始氏族电子族谱/关于.txt");
                        String 说明str = 说明.toString().replaceAll("\\[", "");
                        说明str = 说明str.replaceAll("\\]", "");
                        说明str = 说明str.replaceAll(",", "\n");
                        InputStream is = getResources().openRawResource(R.raw.zfbvx);
                        Bitmap bmp = BitmapFactory.decodeStream(is);
                        imageView.setImageBitmap(bmp);
                        AlertDialog alertDialog = new AlertDialog
                                .Builder(mainform)
                                .setMessage(说明str)
                                .setView(imageView)
                                .create();

                        alertDialog.show();
                    } catch (Resources.NotFoundException e) {
                        e.printStackTrace();
                    }

                } else if (position == 4) {
                    //Toast.makeText(mainform, "about333", Toast.LENGTH_SHORT).show();
                    AlertDialog.Builder ad = new AlertDialog.Builder(mainform);
                    ad.setTitle("说明");
                    ArrayList<String> 说明 = null;
                    说明 = MainActivity.readTxt2("/sdcard/原始氏族电子族谱/说明.txt");
                    String 说明str = 说明.toString().replaceAll("\\[", "");
                    说明str = 说明str.replaceAll("\\]", "");
                    说明str = 说明str.replaceAll(",", "\n");
                    ad.setMessage(说明str);
                    ad.show();

                } else {
                    Intent i = new Intent(MainActivity.this, SingleFragmentActivity.class);
                    i.putExtra(SingleFragmentActivity.FRAGMENT_PARAM, clazz);
                    if (position == 1) {
                        MainActivity.curroot = null;
                        MainActivity.firstform = null;
                        inout.clear();
                    }
                    if (position == 2) {
                        MainActivity.curroot = null;
                        MainActivity.firstform = null;
                        MainActivity.curroot000 = null;
                        inout.clear();
                    }
                    MainActivity.this.startActivity(i);
                }
            }
        });
    }

    private class SimpleArrayAdapter extends ArrayAdapter<String> {
        public SimpleArrayAdapter(Context context, List<String> objects) {
            super(context, android.R.layout.simple_list_item_1, objects);

        }

        @Override
        public long getItemId(int position) {
            return position;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        // Toast toast=Toast.makeText(mainform, "onBackPressed", Toast.LENGTH_SHORT);
    }


}

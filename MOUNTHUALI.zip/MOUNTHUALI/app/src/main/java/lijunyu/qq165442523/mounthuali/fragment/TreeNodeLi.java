package lijunyu.qq165442523.mounthuali.fragment;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import com.unnamed.b.atv.R;
import com.unnamed.b.atv.model.TreeNode;
import com.unnamed.b.atv.view.AndroidTreeView;
import com.unnamed.b.atv.view.TreeNodeWrapperView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * Created by Bogdan Melnychuk on 2/10/15.
 */
public class TreeNodeLi extends TreeNode {
    public String ftext2;
    public String ftext3; 
	public int tag;
     TreeNodeLi() {
         super(0);
    }
}

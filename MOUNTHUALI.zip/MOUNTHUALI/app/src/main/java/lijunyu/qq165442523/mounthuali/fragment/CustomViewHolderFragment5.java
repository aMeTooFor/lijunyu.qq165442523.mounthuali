package lijunyu.qq165442523.mounthuali.fragment;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.unnamed.b.atv.model.TreeNode;
import com.unnamed.b.atv.view.AndroidTreeView;

import java.io.File;
import java.util.ArrayList;

import lijunyu.qq165442523.mounthuali.R;
import lijunyu.qq165442523.mounthuali.activity.MainActivity;
import lijunyu.qq165442523.mounthuali.activity.SingleFragmentActivity;
import lijunyu.qq165442523.mounthuali.holder.HeaderHolder;
import lijunyu.qq165442523.mounthuali.holder.IconTreeItemHolder;
import lijunyu.qq165442523.mounthuali.holder.SelectableHeaderHolder;
import lijunyu.qq165442523.mounthuali.holder.SelectableItemHolder;

/**
 * Created by Bogdan Melnychuk on 2/12/15.
 */
public class CustomViewHolderFragment5 extends Fragment {
    private AndroidTreeView tView;
    public TreeNode 仲荣 = null;
    public ArrayList<String> songIDs = new ArrayList<>();
    public ViewGroup containerView = null;
    public TextView sb = null;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.expandAll:
                // tView.expandAll();

                tView.expandLevel(4);
                //tView.expandLevel(9);

                //   tView.expandNode(仲荣);
                //  tView.toggleNode(仲荣);
//                仲荣.setExpanded(true);
                // tView.selectNode(仲荣,true);
                break;

            case R.id.collapseAll:
                tView.collapseAll();
                break;
        }
        return true;
    }

    public static int getdeep(String oneline) {
        for (int i = 1; i < oneline.length(); i++) {
            if ("0123456789".indexOf(oneline.charAt(i)) == -1) {
                return i;
            }
        }
        return -1;

    }

    public int tree(TreeNode node, String curroot) {

        ArrayList<String> songIDs = MainActivity.readTxt2(curroot + "/子嗣.txt");
        String www = "";
        String vid = "";
        TreeNode cur0 = null;
        TreeNode cur = null;
        TreeNode temp0 = null;
        TreeNode vParentNode = node;
        //node.getParent().setExpanded(false);
        //tView = new AndroidTreeView(getActivity(), root);
        tView.collapseNode(node.getParent());
        node.deleteChild(node.getChildren().get(0));
        int jj0 = 2;
        int jj = 2;
        for (int i = 0; i < songIDs.size(); i++) {
            if (i == songIDs.size() - 2) {
                www = "www";
            }
            www = songIDs.get(i).toString();
            // www=www.replaceAll("<","");
            //www=www.replaceAll(">","");

            jj = getdeep(www);
            vid = www.substring(0, jj);
            www = www.substring(jj);
            if (jj == 3) {
                jj = 2;
            }

            boolean ishavechild = false;
            if ((new File(curroot + "/" + vid)).exists()) {
                ishavechild = true;
            }
            if (i >= (songIDs.size() - 1)) {
                ishavechild = false;
            } else {
                if (getdeep(songIDs.get(i + 1).toString()) == (jj + 2)) {
                    ishavechild = true;
                }
            }
//            if (ishavechild) {//////ic_people  ic_person
//                cur = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_people, www)).setViewHolder(new HeaderHolder(getActivity()));
//            } else {
//                cur = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_person, www)).setViewHolder(new HeaderHolder(getActivity()));
//            }
            if (ishavechild) {//////ic_people  ic_person
                cur = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, www)).setViewHolder(new SelectableHeaderHolder(getActivity()));
                //cur = new TreeNode(www).setViewHolder(new HeaderHolder(getActivity()));
                //cur = new TreeNode(www).setViewHolder(new SelectableHeaderHolder(getActivity()));
            } else {
                //cur = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_person, www)).setViewHolder(new SelectableItemHolder(getActivity()));
                cur = new TreeNode(www).setViewHolder(new SelectableItemHolder(getActivity()));
            }
            cur.ftext2 = vid;
            if (jj == jj0) {
                vParentNode.addChild(cur);
                //vParentNode.isLeaf();  isLeaf()方法是判断是不是node的叶节点。

                jj0 = jj;
                cur0 = cur;
            }
            if (jj - jj0 == 2) {
                vParentNode = cur0;
                vParentNode.addChild(cur);

                jj0 = jj;
                cur0 = cur;
            }
            if (jj < jj0) {
                for (int iFinish = 0; iFinish < Math.floor((jj0 - jj) / 2); iFinish++) {
                    vParentNode = vParentNode.getParent();
                }
                vParentNode.addChild(cur);

                jj0 = jj;
                cur0 = cur;
            }
            String ppp = curroot + "/图片/" + vid + ".jpg";
            cur.ftext3 = ppp;
            ppp = curroot + "/" + vid;
            File file = new File(ppp);
            if (file.exists()) {
                ////ic_people  ic_person
                //temp0 = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_person, "...")).setViewHolder(new HeaderHolder(getActivity()));
                temp0 = new TreeNode("...").setViewHolder(new SelectableItemHolder(getActivity()));
                temp0.ftext2 = ppp;
                cur.addChild(temp0);

            }

        }
        //node.getParent().setExpanded(true);
        tView.expandNode(node.getParent());
        return 1;

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_default, null, false);
        //final ViewGroup
        containerView = (ViewGroup) rootView.findViewById(R.id.container);
        final ViewGroup containerView = (ViewGroup) rootView.findViewById(R.id.container);
        rootView.findViewById(R.id.status_bar).setVisibility(View.VISIBLE);
        sb = rootView.findViewById(R.id.status_bar);

            sb.setText("");


        final TreeNode root = TreeNode.root();
        //TreeNode myProfile = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_people, "黄帝"));
        //ic_people  ic_person
        TreeNode myProfile = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, "太祖"));
        // TreeNode myProfile = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_people, "黄帝")).setViewHolder(new HeaderHolder(getActivity()));
        myProfile.setViewHolder(new HeaderHolder(getActivity()));
        addProfileData(myProfile);
        //addProfileData(clark);
        //addProfileData(bruce);
        //addProfileData(barry);
        //root.addChildren(myProfile, bruce, barry, clark);
        //myProfile.setViewHolder(new SelectableHeaderHolder(MainActivity.mainform));
        //root.addChildren(myProfile);
        root.addChild(myProfile);
        tView = new AndroidTreeView(getActivity(), root);
        tView.setDefaultAnimation(true);
        //tView.setDefaultContainerStyle(R.style.TreeNodeStyleDivided, true);
        tView.setDefaultContainerStyle(R.style.TreeNodeStyleCustom, true);
        //tView.setDefaultContainerStyle(R.style.TreeNodeStyleDivided);
        tView.setDefaultNodeClickListener(nodeClickListener);
        tView.setDefaultNodeLongClickListener(nodeLongClickListener);
        containerView.addView(tView.getView());
        if (MainActivity.curroot == null) {
            tView.expandLevel(3);
        }
        if (savedInstanceState != null) {
            String state = savedInstanceState.getString("tState");
            if (!TextUtils.isEmpty(state)) {
                tView.restoreState(state);
            }
        }
        tView.expandLevel(4);
        return rootView;
    }

    private void addProfileData(TreeNode profile) {
        TreeNode myDocuments = null;
        TreeNode myMedia = null;
        songIDs = MainActivity.readTxt2("/sdcard/原始氏族电子族谱/原始氏族/太祖.txt");
        String www = "";
        for (int i = 0; i < songIDs.size(); i++) {
            www = songIDs.get(i).toString();
            // www=www.replaceAll("<","");
            //www=www.replaceAll(">","");
            //myDocuments = (new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_drive_file, www)));
            myDocuments = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_people, www)).setViewHolder(new HeaderHolder(getActivity()));
            profile.addChild(myDocuments);
        }
        songIDs = MainActivity.readTxt2("/sdcard/原始氏族电子族谱/原始氏族/高祖.txt");
        www = "";
        for (int i = 0; i < songIDs.size(); i++) {
            www = songIDs.get(i).toString();
            // www=www.replaceAll("<","");
            //www=www.replaceAll(">","");
             myMedia = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_people, www)).setViewHolder(new HeaderHolder(getActivity()));
            myDocuments.addChild(myMedia);

        }
        仲荣 = myMedia;
        TreeNode temp0 = null;
        TreeNode cur0 = null;
        TreeNode cur = null;
        TreeNode vParentNode = null;
        vParentNode = 仲荣;
        songIDs = MainActivity.readTxt2("/sdcard/原始氏族电子族谱/原始氏族/世祖/子嗣.txt");
        www = "";
        String vid = "";
        int jj0 = 2;
        int jj = 2;
        for (int i = 0; i < songIDs.size(); i++) {
            www = songIDs.get(i).toString();
            // www=www.replaceAll("<","");
            //www=www.replaceAll(">","");
            if (www.equals("03030402寿官")) {
                www = "03030402温";
            }
            if (www.equals("030302福隆<徒>")) {
                www = "030302福隆";
            }
            jj = getdeep(www);
            vid = www.substring(0, jj);
            www = www.substring(jj);
            if (jj == 3) {
                jj = 2;
            }

            boolean ishavechild = false;
            if ((new File("/sdcard/原始氏族电子族谱/原始氏族/世祖/" + vid)).exists()) {
                ishavechild = true;
            }
            if (i >= (songIDs.size() - 1)) {
                ishavechild = false;
            } else {
                if (getdeep(songIDs.get(i + 1).toString()) == (jj + 2)) {
                    ishavechild = true;
                }
            }
            if (ishavechild) {//////ic_people  ic_person
                cur = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_folder, www)).setViewHolder(new SelectableHeaderHolder(getActivity()));
                //cur = new TreeNode(www).setViewHolder(new HeaderHolder(getActivity()));
                //cur = new TreeNode(www).setViewHolder(new SelectableHeaderHolder(getActivity()));
            } else {
                //cur = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_person, www)).setViewHolder(new SelectableItemHolder(getActivity()));
                cur = new TreeNode(www).setViewHolder(new SelectableItemHolder(getActivity()));
            }
            cur.ftext2 = vid;

            if (jj == jj0) {
                vParentNode.addChild(cur);
                //vParentNode.isLeaf();  isLeaf()方法是判断是不是node的叶节点。
                //((IconTreeItemHolder.IconTreeItem)vParentNode).icon=R.string.ic_person;
                // vParentNode.setViewHolder()
                jj0 = jj;
                cur0 = cur;
            }
            if (jj - jj0 == 2) {
                vParentNode = cur0;
                vParentNode.addChild(cur);
                //((IconTreeItemHolder.IconTreeItem) vParentNode.getValue()).icon = R.string.ic_person;
                jj0 = jj;
                cur0 = cur;
            }
            if (jj < jj0) {
                for (int iFinish = 0; iFinish < Math.floor((jj0 - jj) / 2); iFinish++) {
                    vParentNode = vParentNode.getParent();
                }
                vParentNode.addChild(cur);
                // ((IconTreeItemHolder.IconTreeItem) vParentNode.getValue()).icon = R.string.ic_person;
                jj0 = jj;
                cur0 = cur;
            }
            String ppp = "/sdcard/原始氏族电子族谱/原始氏族/世祖/图片/" + vid + ".jpg";
            cur.ftext3 = ppp;
            ppp = "/sdcard/原始氏族电子族谱/原始氏族/世祖/" + vid;
            File file = new File(ppp);
            if (file.exists()) {
                //temp0 = new TreeNode(new IconTreeItemHolder.IconTreeItem(R.string.ic_people, "...")).setViewHolder(new HeaderHolder(getActivity()));
                temp0 = new TreeNode("...").setViewHolder(new SelectableItemHolder(getActivity()));
                temp0.ftext2 = ppp;
                cur.addChild(temp0);
                // ((IconTreeItemHolder.IconTreeItem) cur.getValue()).icon = R.string.ic_person;
            }

        }
    }

    private TreeNode.TreeNodeClickListener nodeClickListener = new TreeNode.TreeNodeClickListener() {
        @Override
        public void onClick(TreeNode node, Object value) {
            //IconTreeItemHolder.IconTreeItem item = (IconTreeItemHolder.IconTreeItem) value;
            //statusBar.setText("最近点击的是: " + item.text);
            TreeNode node1 = null;
            if (!node.isLeaf()) {
                node1 = node.getChildren().get(0);
                //IconTreeItemHolder.IconTreeItem item1 = (IconTreeItemHolder.IconTreeItem) node1.getValue();
                //node1.getValue().toString()
                if (node1.getValue().toString().equals("...")) {

                    //if (!node.isExpanded()) {
                    //Toast.makeText(getActivity(), node1.ftext2, Toast.LENGTH_SHORT).show();
                    tree(node, node1.ftext2);


                    //}
                }
            }
        }
    };

    private TreeNode.TreeNodeLongClickListener nodeLongClickListener = new TreeNode.TreeNodeLongClickListener() {
        @Override
        public boolean onLongClick(TreeNode node, Object value) {
            if (node.getLevel() < 4) {
                Toast.makeText(getActivity(), "以下才可弹出菜单信息 ", Toast.LENGTH_SHORT).show();
                return true;
            }
            String nodetext = "";
            if (node.isLeaf()) {
                nodetext = value.toString();
            } else {
                IconTreeItemHolder.IconTreeItem item = (IconTreeItemHolder.IconTreeItem) value;
                nodetext = item.text;
            }
            //Toast.makeText(getActivity(), "Long click: " + item.text, Toast.LENGTH_SHORT).show();
            AlertDialog alertDialog1; //信息框
            String 打开相关图片 = "";
            String 第n世 = "";
            String 备注 = "备注:";
            String 认祖归宗 = "认祖归宗：";
            if (node.getLevel() < 4) {
                第n世 = "";
            } else {
                if (node.isLeaf()) {
                    第n世 = "第" + (node.getLevel() - 2) + "世 有子嗣 0 人" + " 兄弟共 " + node.getParent().getChildren().size() + "人";
                } else {
                    第n世 = "第" + (node.getLevel() - 2) + "世 有子嗣 " + node.getChildren().size() + " 人" + " 兄弟共 " + node.getParent().getChildren().size() + "人";
                }
                for (int ijk = 0; ijk < node.getParent().getChildren().size(); ijk++) {
                    if (node.getParent().getChildren().get(ijk).equals(node)) {
                        第n世 = 第n世 + " 在兄弟中排行第 " + (ijk + 1);
                    }
                }
            }
            第n世 = "③" + 第n世 + " 说明：子嗣数是动态统计，如果显示0，也可能是没有录入数据之因，特此说明。 ";
            /////////////////////////////////////
            ArrayList<String> 子嗣 = null;
            ArrayList<String> 附加 = null;
            String vpath = node.ftext3;
            vpath = vpath.replace("/图片/", "/");
            vpath = vpath.substring(0, vpath.lastIndexOf("/"));
            // vpath=vpath+"/子嗣.txt";
            子嗣 = MainActivity.readTxt2(vpath + "/子嗣.txt");
            String www = "";
            String vid = "";
            String vvid = "";
            int jj0 = 2;
            int jj = 2;
            for (int i = 0; i < 子嗣.size(); i++) {
                www = 子嗣.get(i).toString();
                // www=www.replaceAll("<","");
                //www=www.replaceAll(">","");
                jj = getdeep(www);
                vid = www.substring(0, jj);
                www = www.substring(jj);
                if (nodetext.equals(www)) {
                    break;
                }
            }

            vid = node.ftext2;
            附加 = MainActivity.readTxt2(vpath + "/附加.txt");
            www = "";
            vvid = "";
            jj0 = 2;
            jj = 2;
            for (int i = 0; i < 附加.size(); i++) {
                www = 附加.get(i).toString();
                // www=www.replaceAll("<","");
                //www=www.replaceAll(">","");

                jj = getdeep(www);
                vvid = www.substring(0, jj);
                www = www.substring(jj);
                if (vid.equals(vvid)) {
                    备注 = "④备注:" + www;
                    break;
                }
            }
            //vvid = node.ftext2;
            /////////////////////////////////////////
            认祖归宗 = "⑤认祖归宗：";
            String 认祖归宗0 = "";
            if (nodetext.indexOf("<") > 0) {
                认祖归宗 = 认祖归宗 + nodetext.substring(0, nodetext.indexOf("<")) + "->";
            }else{
                认祖归宗 = 认祖归宗 + nodetext + "->";
            }
            TreeNode curnode = node.getParent();
            IconTreeItemHolder.IconTreeItem curitem = (IconTreeItemHolder.IconTreeItem) curnode.getValue();
            //while (!curitem.text.equals("黄帝")) {
            while (!node.getRoot().equals(curnode)) {
                if (curitem.text.indexOf("<") > 0) {
                    认祖归宗 = 认祖归宗 + curitem.text.substring(0, curitem.text.indexOf("<")) + "->";
                    认祖归宗0 = 认祖归宗0 + curitem.text.substring(0, curitem.text.indexOf("<")) + "->";
                } else {
                    认祖归宗 = 认祖归宗 + curitem.text + "->";
                    认祖归宗0 = 认祖归宗0 + curitem.text + "->";
                }
                curnode = curnode.getParent();
                curitem = (IconTreeItemHolder.IconTreeItem) curnode.getValue();
            }
            认祖归宗 = 认祖归宗 + "黄帝";
            认祖归宗0 = 认祖归宗0+ "黄帝";
            认祖归宗 = 认祖归宗.replace("仲荣->晟->黄帝", "仲荣...晟...黄帝");
            认祖归宗0 = 认祖归宗0.replace("仲荣->晟->黄帝", "仲荣...晟...黄帝");
            final String ppp = node.ftext3;
            File dir = new File(ppp);
            if (!dir.exists()) {
                打开相关图片 = "② 找不到相关图片";
            } else {
                打开相关图片 = "② 打开相关图片";
            }
            final String[] items = {"①作为根节点打开", 打开相关图片, 第n世, 备注, 认祖归宗};
            AlertDialog.Builder alertBuilder = new AlertDialog.Builder(getActivity());
            alertBuilder.setTitle("【" + nodetext + "】");
            final TreeNode curroot = node;
            final String 认祖归宗00=认祖归宗0.replace("⑤认祖归宗：","");
            alertBuilder.setItems(items, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (items[i].equals("② 打开相关图片")) {
                        //Toast.makeText(getActivity(), "【打开相关图片】功能还在开发中...", Toast.LENGTH_SHORT).show();

                        File file = new File(ppp);
                        if (!file.exists()) {
                            return;
                        }
                        try {

//                            Intent intents = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
////                            intents.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(file));
////                            startActivity(intents);
                            //File file = new File(filepath);
                            ImageView imageView = new ImageView(getActivity());//创建一个imageView对象
                            if (file.exists()) {
                                Bitmap bm = BitmapFactory.decodeFile(ppp);
                                // 将图片显示到ImageView中
                                imageView.setImageBitmap(bm);
                                //linearLayout1.addView(imageView);
                                AlertDialog alertDialog = new AlertDialog
                                        .Builder(getActivity())
                                        .setView(imageView)
                                        .create();

                                alertDialog.show();


                            }


                        } catch (Exception e) {
                            Toast.makeText(getActivity(), "已找到图片，但无法显示", Toast.LENGTH_SHORT).show();

                        }
                    }
                    if (items[i].equals("①作为根节点打开")) {
                        //Toast.makeText(getActivity(), "①作为根节点打开", Toast.LENGTH_SHORT).show();
                        MainActivity.curroot=curroot;
                        Intent iii = new Intent(getActivity(), SingleFragmentActivity.class);
                        iii.putExtra(SingleFragmentActivity.FRAGMENT_PARAM, CustomViewHolderFragment666.class);
                        iii.putExtra("path0", 认祖归宗00);
                        iii.putExtra("level0", curroot.getLevel() - 2);
                        MainActivity.path0=认祖归宗00;
                        MainActivity.level0=curroot.getLevel() - 2;
/*                        ArrayList<TreeNode> personList= new ArrayList<TreeNode>();
                        personList.add(curroot);
                        for (int jjj=0;jjj<curroot.getChildren().size();jjj++){
                            personList.add(curroot.getChildren().get(jjj));
                        }
                        iii.putExtra("curroot",personList);*/
                        getActivity().startActivity(iii);

                        /*TreeNode root0 = curroot.getRoot();//TreeNode.root();//TreeNode.root();

                        tView.removeNode(root0);

                        TreeNode root = TreeNode.root();//TreeNode.root();
                        //root.deleteChild(root.getChildren().get(0));
                        curroot.getParent().deleteChild(curroot);
                        root.addChild(curroot);
                        tView = new AndroidTreeView(getActivity(), root);
                        tView.setDefaultAnimation(true);
                        //tView.setDefaultContainerStyle(R.style.TreeNodeStyleDivided, true);
                        tView.setDefaultContainerStyle(R.style.TreeNodeStyleCustom, true);
                        //tView.setDefaultContainerStyle(R.style.TreeNodeStyleDivided);
                        tView.setDefaultNodeClickListener(nodeClickListener);
                        tView.setDefaultNodeLongClickListener(nodeLongClickListener);
                        containerView.removeAllViews();
                        containerView.addView(tView.getView());*/


                    }

                }
            });
            alertBuilder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {
                    // TODO Auto-generated method stub
                    dialog.dismiss();
                }
            });


            alertDialog1 = alertBuilder.create();
            alertDialog1.show();
            return true;
        }
    };

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("tState", tView.getSaveState());
    }
}
